# file pyquasar_test.py
# Run: python -m unittest test.pyquasar_test

# Or: python -m unittest discover

# 1. You define your own class derived from unittest.TestCase.
# 2. Then you fill it with functions that start with 'test_'
# 3. You run the tests by placing unittest.main() in your file, usually at the bottom.

# https://docs.python.org/2/library/unittest.html#test-cases

import unittest
import os
from pyquasar import *

class TestProcess(unittest.TestCase):
 
    def test_univariate(self):
        ARModel("Demand", 25, 5, [0.5], initial_state=[25], truncate=[0,100])

        ARMAModel("Demand", 50, 10, [0.5, 1], [0.5, 1], truncate=[0,100])
        initial_price = 28.
        drift = 0.
        volatility = 0.2
        uni_gbm = UnivariateGBM("price", initial_price, drift, volatility)
        uni_gbm.sample(20, 20)

        inflowProcess = StochasticTrendModel.from_data(
            'Inflow', 365,
            source=os.path.join(os.path.dirname(__file__), 'imports/inflows.csv'),
            smoothing_method='kernel_density',
            log_transform=True,
            truncate=True,
            initial_state=3.4,
            csv_options={'sep': ','}
        )

    def test_aggregated(self):
        initial_price = 28.
        drift = 0.
        volatility = 0.2
        uni_gbm = UnivariateGBM("price", initial_price, drift, volatility)
        AggregatedProcess(uni_gbm, 15)
        AggregatedProcess(uni_gbm, [15, 12])

    def test_lattice(self):
        initial_price = 28.
        drift = 0.
        volatility = 0.2
        uni_gbm = UnivariateGBM("Demand", initial_price, drift, volatility)
        lat = Lattice(process=uni_gbm, num_stages=8, state_variables=['Demand'], growth_rate='SQUARE_ROOT', num_nodes=60, sample_size=300, distance='MAXIMUM')


    def test_multivariate(self):
        my_gbm = MultivariateGBM(
            ["Demand0", "Demand1", "Demand2"],
            [10, 10, 10], [0, 0, 0],
            [0.2, 0.2, 0.2],
            [[1, 0.3, 0.7], [0.3, 1, 0], [0.7, 0, 1]])

        names = ['x', 'y']
        means = [4, 5]
        cov = [[1, 0.5], [0.5,1]]
        my_var = VARProcess(names, means, cov, [[[0.7], [0.2]], [[0.2], [0.7]]], truncate_zero=True, warm_up_phase=100)

        real_sample = QuasarDataFrame.from_csv(os.path.join(os.path.dirname(__file__), 'imports/price_sample_13-14.csv'))
        print(real_sample)

        p = VARProcess.from_data(
            os.path.join(os.path.dirname(__file__), 'imports/preismodell-2010-2012.csv'),
            periodic_bootstrap=31,
            seasonal_cycle=[365],
            dependency=[[0, 0, [1, 2, 5]], ['Preis_0', 'Preis_1', [1, 2, 5]]],
            truncate=True,
            warm_up_phase = 365,
            linear_trend=[4, 3, 4],
            log_transform = [4, 6, 7],
            lag = [[4, 5], [6, 7]],
            csv_options={'sep': ','}
        )

        combined = my_gbm + my_var

        # StateSpaceProcess(['s0', 's1', 's2'], ['m1', 'm2', 'm3'])
        # d0, d1, d2 = my_gbm.sample(10, 100)
        # d1.df.describe()
        #
        # d0 = my_gbm.sample(var='Demand0')
        # d0.df.describe()


if __name__ == '__main__':
    unittest.main()