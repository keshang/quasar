# file pyquasar_test.py
# Run: python -m unittest test.pyquasar_test

# Or: python -m unittest discover

# 1. You define your own class derived from unittest.TestCase.
# 2. Then you fill it with functions that start with 'test_'
# 3. You run the tests by placing unittest.main() in your file, usually at the bottom.

# https://docs.python.org/2/library/unittest.html#test-cases

import unittest
from pyquasar import *

class TestQuasar(unittest.TestCase):
 
    def setUp(self):
        #stochastic model
        initialPrice = 28
        priceSpread = 0.02
        drift = 0
        volatility = 0.2
        gbm = UnivariateGBM("price", initialPrice, drift, volatility)

        #decision problem
        numStages = 12
        model = DecisionProblem("GasStorage").maximize()
        for t in range(0, numStages):
            inject = model.add_variable(t, 'inject', ub=0.3)
            withdraw, content = model.add_variables(t, num_vars=2)
            #storage balance
            model += content == (lastContent if t>0 else 0) + 0.99*inject - 1.01*withdraw
            lastContent = content
            #objective function
            model += 0.99*rand("price")*withdraw - 1.01*rand("price")*inject
            #bounds
            # model += inject <= 0.3
            model += withdraw <= 0.3
            model += content <= 1

        opt = DynamicOptimizer(model, gbm, num_threads=1)
        pol = opt.solve(10)

    # def test_simulation(self):
    #
    #     exp = {
    #             'decision': {
    #                 u'inject': 0.29999999999999999,
    #                 u'storage': 0.29699999999999999,
    #                 u'withdraw': 0.0},
    #             'shadow_price': {
    #                 u'inject': '',
    #                 u'storage': 29.9556,
    #                 u'withdraw': ''}
    #         }
    #     act = self.sol.summary().to_dict()
    #
    #     self.assertAlmostEqual(exp['decision']['inject'], act['decision']['inject'], 0)
    #     self.assertAlmostEqual(exp['decision']['storage'], act['decision']['storage'], 0)
    #     self.assertAlmostEqual(exp['shadow_price']['storage'], act['shadow_price']['storage'], -1)

    def test_overloads(self):
        x, y = DecisionProblem().add_variables(0, "x", "y")
        #x = DecisionVariable(0, "x")
        #y = DecisionVariable(0, "y")
        rand = RandomVariable("rand")

        # expression: result
        tests = {
            'x-rand': '-rand+x',
            '-rand-x': '-rand-x',
            '2*rand': '2.0 rand',
            '2*x': '2.0 x',
            'x*2': '2.0 x',
            '2*rand*x': '(2.0 rand) x',
            '2*x*rand': '(2.0 rand) x',
            'rand*2*x': '(2.0 rand) x',
            'rand*x*2': '(2.0 rand) x',
            'x*2*rand': '(2.0 rand) x',
            'x*rand*2': '(2.0 rand) x',
            '-2*rand': '-2.0 rand',
            '-2*x': '-2.0 x',
            '-x*2': '-2.0 x',
            'rand+1': '1.0+rand',
            'rand+3': '3.0+rand',
            '3+rand': '3.0+rand',
            '3-rand': '3.0-rand',
            'rand-3': '-3.0+rand',
            'x-3': '-3.0+x',
            '3-x': '3.0-x',
            'x/2' : '0.5 x',
            'rand/2' : '0.5 rand'
        }

        for t in tests:
            print(str(eval(t))+" "+tests[t])
            self.assertEqual( (eval(t)).__repr__().strip(), tests[t])

    def test_rand(self):
        model = DecisionProblem("KampHydro").maximize()
        t = 0
        shift = 4
        turbine, spill = model.add_variables(t, "turbine", "spill", num_vars = 2)

        expr = (rand("price")-shift)*(turbine-spill)
        self.assertTrue(expr.__repr__() == ' (-4.0+price) turbine + (4.0-price) spill '
                        or expr.__repr__() == ' (4.0-price) spill + (-4.0+price) turbine ')
 
if __name__ == '__main__':
    unittest.main()