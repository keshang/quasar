# file pyquasar_test.py
# Run: python -m unittest test.pyquasar_test

# Or: python -m unittest discover

# 1. You define your own class derived from unittest.TestCase.
# 2. Then you fill it with functions that start with 'test_'
# 3. You run the tests by placing unittest.main() in your file, usually at the bottom.

# https://docs.python.org/2/library/unittest.html#test-cases

import unittest
from pyquasar import *

class TestLattice(unittest.TestCase):

    def make_lattice(self,num_stages):
        gbm = MultivariateGBM(
            ["Demand0", "Demand1", "Demand2"],
            [10, 10, 10], [0, 0, 0],
            [0.2, 0.2, 0.2],
            [[1, 0.3, 0.7], [0.3, 1, 0], [0.7, 0, 1]])

        lattice = Lattice(
            process=gbm,
            num_stages=num_stages,
            num_nodes=10,
            growth_rate='SQUARE_ROOT',
            distance='SQUARED',
            scenario_reduction_method='MARGINAL_KMEANS',
            state_variables=['Demand0','Demand1']
        )

        return lattice
 
    def test_sim(self):
        num_stages = 12
        sim_lattice = self.make_lattice(num_stages)

        sim_lattice.log()
        sim_lattice.arcsinh()
        sim_lattice.sinh()
        sim_lattice.exp()
        sim_lattice.mul([[1.]*3]*num_stages)
        sim_lattice.add([[0.]*3]*num_stages)

        self.assertEqual(sim_lattice.num_stages(),num_stages)
        num_nodes = sim_lattice.num_nodes()
        num_nodes = sim_lattice.num_nodes_stage(11)
        with self.assertRaises(Exception):
            print(sim_lattice.num_nodes_stage(12))

    def test_csv(self):
        num_stages = 12
        csv_lattice = self.make_lattice(num_stages)
        self.assertEqual(csv_lattice.num_stages(),num_stages)
        num_nodes = csv_lattice.num_nodes()
        name = 'test_lattice'
        csv_lattice.to_csv(name)
        csv_lattice = Lattice.from_csv(name)
        self.assertEqual(csv_lattice.num_stages(),num_stages)
        self.assertEqual(csv_lattice.num_nodes(),num_nodes)

    def test_data(self):
        num_stages = 7
        num_nodes = (num_stages-1)*10+1
        df = pd.DataFrame.from_csv(os.path.join(os.path.dirname(__file__), 'imports/prices.csv'), sep=',',index_col=0)
        data_lattice = Lattice.from_data(df,df.columns,7,10,
                                         periodic=7,
                                         num_passes=20,
                                         initial_state=[0.]*24)
        self.assertEqual(data_lattice.num_stages(),num_stages)
        self.assertEqual(data_lattice.num_nodes(),num_nodes)


if __name__ == '__main__':
    unittest.main()