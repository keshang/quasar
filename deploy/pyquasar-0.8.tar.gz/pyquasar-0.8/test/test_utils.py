import unittest
import pandas as pd

from pyquasar.process import TimeSeriesRegression


class TestProcess(unittest.TestCase):
 
    def test_time_series_regression(self):
        df = pd.DataFrame.from_csv("imports/preismodell-2010-2012.csv")
        data = df['Preis_12'].values
        ts = TimeSeriesRegression(data,
                                  seasonal_cycle=365,
                                  model_selection='AIC')

        self.assertTrue(len(ts.errors()) == len(data))
        self.assertTrue(len(ts.trend()) == len(data))
        self.assertTrue(len(ts.season()) == len(data))
        self.assertTrue(len(ts.explanatory()) == len(data))

        exp = [[(1. if i%7==j else 0.) for j in range(6)] for i in range(len(data))]
        ts = TimeSeriesRegression(data,
                                  explanatory_values = exp,
                                  explanatory_names = ["day_%d"%i for i in range(6)],
                                  seasonal_cycle=(365),
                                  local_trend=7,
                                  model_selection='BIC')

        self.assertTrue(len(ts.explanatory()) == len(data))

        # TODO: not sure this does anything at all.
        with self.assertRaises(Exception):
            ts.predict(20)
        with self.assertRaises(Exception):
            ts.predict(20,explanatory=exp[:30])
        with self.assertRaises(Exception):
            RuntimeError,ts.predict(20,explanatory=exp[:14])

        ts.predict(20, explanatory=exp[:20])
        ts.summary()

if __name__ == '__main__':
    unittest.main()