# file pyquasar_test.py
# Run: python -m unittest test.pyquasar_test

# Or: python -m unittest discover

# 1. You define your own class derived from unittest.TestCase.
# 2. Then you fill it with functions that start with 'test_'
# 3. You run the tests by placing unittest.main() in your file, usually at the bottom.

# https://docs.python.org/2/library/unittest.html#test-cases

import unittest
from pyquasar import *

class TestPlotting(unittest.TestCase):
 
    def setUp(self):
        model = DecisionProblem("Production").maximize()
        process = ARModel("Demand", 25, 5, [0.5])

        initInventory = 20

        for t in range(9):
            inventory, produce, sell = model.add_variables(t, "inventory", "produce", "sell")

            #objective function
            model += 5*sell - 3*produce - 0.5*inventory

            #inventory balance
            model += inventory == (oldInventory if t > 0 else initInventory) - sell + produce

            #bounds
            model += sell <= inventory
            model += produce <= 50
            oldInventory = inventory

        self.model = model
        self.process = process

    def test_plots(self):
        opt = DynamicOptimizer(self.model, self.process, sampling_strategy='markovian',num_threads=1, linear_solver='clp')
        opt.solve(time_limit=5)
        opt.join()
        sim = opt.policy.simulate(30)
        sim.decision.sell.fanchart()


if __name__ == '__main__':
    unittest.main()