# file pyquasar_test.py
# Run: python -m unittest test.pyquasar_test

# Or: python -m unittest discover

# 1. You define your own class derived from unittest.TestCase.
# 2. Then you fill it with functions that start with 'test_'
# 3. You run the tests by placing unittest.main() in your file, usually at the bottom.

# https://docs.python.org/2/library/unittest.html#test-cases

import unittest

from pyquasar import *

class TestSolver(unittest.TestCase):
 
    def setUp(self):
        model = DecisionProblem("Production").maximize()
        process = ARModel("Demand", 25, 5, [0.5], truncate_zero=True) #ARModel("Demand", 25, 5, [0.5])

        oldInventory = 20

        for t in range(9):
            produce, inventory, sell = model.add_variables(t, num_vars=3)

            #objective function
            #print(5*sell - 3*produce - 0.5*inventory)
            model += 5*sell - 0.5*inventory - 3*produce

            #inventory balance
            model += inventory == oldInventory - sell + produce

            #bounds
            model += sell <= rand("Demand")
            model += sell <= inventory
            model += (10 <= produce) <= 50
            oldInventory = inventory

        self.model = model
        self.process = process

    def test_iterations(self):
        opt = DynamicOptimizer(self.model, self.process, sampling_strategy='markovian', num_threads=1)
        opt.solve(max_iterations=3)
        opt.join()
        self.assertEqual(len(opt.stats), 3)

    def test_dynamic_solver(self):
        opt = DynamicOptimizer(self.model, self.process, sampling_strategy='markovian', num_threads=1)
        opt.solve(time_limit=5)
        opt.policy.first_stage_solution()

    def test_dynamic_solver2(self):
        opt = DynamicOptimizer(self.model, self.process, sampling_strategy='markovian', num_threads=1)
        opt.solve(max_iterations=5)
        opt.join()
        self.assertEqual(5, len(opt.stats))

    def test_static_solver(self):
        opt = StaticOptimizer(self.model, self.process, update_expectations=True, linear_solver='sulum', num_threads=1)
        opt.get_clairvoyant(50)
        opt.get_expected_value()
        opt.policy.simulate(sample_size=50)

    def test_simulation(self):
        opt = DynamicOptimizer(self.model, self.process, sampling_strategy='markovian', num_threads=1)
        opt.solve()
        opt.join()
        opt.policy.simulate()

    # def test_simulation(self):
    #
    #     exp = {
    #             'decision': {
    #                 u'inject': 0.29999999999999999,
    #                 u'storage': 0.29699999999999999,
    #                 u'withdraw': 0.0},
    #             'shadow_price': {
    #                 u'inject': '',
    #                 u'storage': 29.9556,
    #                 u'withdraw': ''}
    #         }
    #     act = self.sol.summary().to_dict()
    #
    #     self.assertAlmostEqual(exp['decision']['inject'], act['decision']['inject'], 0)
    #     self.assertAlmostEqual(exp['decision']['storage'], act['decision']['storage'], 0)
    #     self.assertAlmostEqual(exp['shadow_price']['storage'], act['shadow_price']['storage'], -1)

    def test_overloads(self):
        x, y = DecisionProblem('testmodel').add_variables(0, "x", "y")
        rand = RandomVariable("rand")

        # expression: result
        tests = {
            '2*rand': '2.0 rand',
            '2*x': '2.0 x',
            'x*2': '2.0 x',
            '2*rand*x': '(2.0 rand) x',
            '2*x*rand': '(2.0 rand) x',
            'rand*2*x': '(2.0 rand) x',
            'rand*x*2': '(2.0 rand) x',
            'x*2*rand': '(2.0 rand) x',
            'x*rand*2': '(2.0 rand) x',
            '-2*rand': '-2.0 rand',
            '-2*x': '-2.0 x',
            '-x*2': '-2.0 x',
            'rand+1': '1.0+rand',
            'rand+3': '3.0+rand',
            '3+rand': '3.0+rand',
            '3-rand': '3.0-rand',
            'rand-3': '-3.0+rand',
            'x-3': '-3.0+x',
            '3-x': '3.0-x'
        }

        for t in tests:
            #print("%s"%(type(eval(t)))+" "+eval(t).__repr__()+" "+tests[t])
            self.assertEqual(eval(t).__repr__().strip(), tests[t])


if __name__ == '__main__':
    unittest.main()
