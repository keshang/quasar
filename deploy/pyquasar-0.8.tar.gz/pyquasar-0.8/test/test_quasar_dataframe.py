import unittest
import os
from pyquasar import *

class TestQuasarDataFrame(unittest.TestCase):
 
    def setUp(self):
        model = DecisionProblem("Production").maximize()
        process = ARModel("Demand", 25, 5, [0.5])

        initInventory = 20

        for t in range(9):
            inventory, produce, sell = model.add_variables(t, "inventory", "produce", "sell")

            #objective function
            model += 5*sell - 3*produce - 0.5*inventory

            #inventory balance
            model += inventory == (oldInventory if t > 0 else initInventory) - sell + produce

            #bounds
            model += sell <= inventory
            model += produce <= 50
            oldInventory = inventory

        self.model = model
        self.process = process

    def test_from_simulation(self):
        opt = DynamicOptimizer(self.model, self.process, sampling_strategy='MARKOVIAN', num_threads=1, linear_solver='CLP')
        opt.solve(time_limit=5)
        opt.join()
        opt.plot()
        qdf = opt.policy.simulate(30)
        print(qdf.columns)

    def test_csv_import_full(self):
        csv_file = 'simulation_qdf.csv'
        opt = DynamicOptimizer(self.model, self.process, sampling_strategy='MARKOVIAN', num_threads=1, linear_solver='CLP')
        opt.solve(time_limit=5)
        opt.join()
        opt.plot()
        sim = opt.policy.simulate(30)
        sim.to_csv(csv_file)

        sim2 = QuasarDataFrame.from_csv(csv_file)
        self.assertAlmostEqual(sim2.rewards.rewards.sum(), sim.rewards.rewards.sum(), 2)
        self.assertAlmostEqual(sim2.decision.sell.sum(), sim.decision.sell.sum(), 2)

        os.remove(csv_file)

    def test_csv_import_simple(self):
        csv_file = 'ar_model.csv'
        ar_model = ARModel(name="demand",
                           constant=1.0,
                           sigma=1.2,
                           ar_coefficients=[0.8],
                           # initial_state=[5.0],
                           truncate_zero=True)
        sim = ar_model.simulate(num_stages=5, sample_size=5)
        sim.to_csv(csv_file)

        sim2 = QuasarDataFrame.from_csv(csv_file)
        self.assertAlmostEqual(sim2.demand.sum(), sim.demand.sum(), 2)

        os.remove(csv_file)

    def test_from_sample(self):
        self.process.sample(20)


if __name__ == '__main__':
    unittest.main()