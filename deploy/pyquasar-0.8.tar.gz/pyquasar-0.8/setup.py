import re
import ast
from setuptools import setup

_version_re = re.compile(r'__version__\s+=\s+(.*)')

with open('pyquasar/__init__.py', 'rb') as f:
    version = str(ast.literal_eval(_version_re.search(
        f.read().decode('utf-8')).group(1)))

description = 'Python bindings for QUASAR Java library.'

setup(
        name='pyquasar',
        author='"Manuel Riel, Nils Loehndorf"',
        author_email='info@quantego.com',
        version=version,
        license='LICENSE.txt',
        url='http://www.quantego.com',
        description=description,
        long_description=description,
        packages=['pyquasar', 'pyquasar.process'],
        package_data={'pyquasar': ['assets/mplstyle/*']},
        install_requires=[
             'JPype1',
             'pandas',
             'mpltools',
             'pyzmq',
             'tornado',
             'statsmodels',
             'bunch',
             'pytz',
             'python-dateutil',
             'six',
             'numexpr',
             'bottleneck',
             'scipy',
             'pygments ',
             'matplotlib',
             'scikit-learn',
             'jsonpointer',
             'jsonschema',
             'ipython',
             'mistune',
             'terminado',
             'jinja2',
             'pycontracts'
            ],
        classifiers=[
            'Development Status :: 4 - Beta',
            'Environment :: Web Environment',
            'Intended Audience :: End Users/Desktop',
            'License :: Other/Proprietary License',
            'Operating System :: Unix',
            'Programming Language :: Python',
            'Programming Language :: Python :: 2.7',
            'Topic :: Scientific/Engineering :: Information Analysis',
            ],
        )