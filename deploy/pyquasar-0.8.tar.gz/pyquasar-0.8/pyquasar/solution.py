import json
import pandas as pd

def _hash2dict(hm):
    output = {}
    if hm is None: return output

    for k in hm.keySet().toArray():
        try:
            output[k] = float(str(hm[k]))
        except:
            pass

    return output

class Solution:
    """Holds all available information about the solution of a subproblem for a given State by following a Policy.

    Attributes:
      decision (dict): Solution values of all decision variables.
      reward (float): Realized immediate reward
      shadow_price (dict): Shadow prices

    """

    def __init__(self, java_solution):
        self._inner = java_solution
        self.decision = _hash2dict( self._inner.getDecisions() )
        #self.dual_solution = _hash2dict( self._inner.getDualSolutions() )
        self.reward = self._inner.getReward()
        self.shadow_price = _hash2dict( self._inner.getShadowPrices() )

    def __str__(self):
        output = ""
        output += '# Reward: %s\n' % self.reward

        output += '\n\n# Decisions\n'
        output += json.dumps(self.decisions, indent=1)

        output += '\n# Shadow prices\n'
        output += json.dumps(self.shadow_prices, indent=1)

        return output

    def __repr__(self):
        return self.__str__()
