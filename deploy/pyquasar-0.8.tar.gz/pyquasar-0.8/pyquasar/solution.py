import json
import pandas as pd
from json import encoder

def _hash2dict(hm):
    output = {}
    if hm is None: return output

    for k in hm.keySet().toArray():
        try:
            output[k] = float(str(hm[k]))
        except:
            pass

    return output

class Solution:
    """Holds all available information about the solution of a subproblem for a given State by following a Policy.

    Attributes:
      decision (dict): Solution values of all decision variables.
      reward (float): Realized immediate reward
      shadow_price (dict): Shadow prices

    """

    def __init__(self, java_solution):
        self._inner = java_solution
        self.decisions = _hash2dict( self._inner.getDecisions() )
        #self.dual_solution = _hash2dict( self._inner.getDualSolutions() )
        self.reward = self._inner.getReward()
        self.shadow_prices = _hash2dict( self._inner.getShadowPrices() )

    def __str__(self):
        out = {}
        out['rewards'] = self.reward
        out['decisions'] = self.decisions
        out['shadow_prices'] = self.shadow_prices

        encoder.FLOAT_REPR = lambda o: format(o, '.2f') # monkey-patch output format
        return json.dumps(out, indent=2, sort_keys=True)

    def __repr__(self):
        return self.__str__()
