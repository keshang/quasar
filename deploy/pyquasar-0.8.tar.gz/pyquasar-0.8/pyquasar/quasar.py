import jpype
import platform
import glob
import pkg_resources

if platform.system() == 'Darwin':
    jvm = glob.glob('/Library/Java/JavaVirtualMachines/jdk1.7.*.jdk/Contents/MacOS/libjli.dylib')
    jvm.reverse() #newest first
    jvm = jvm[0]
else:
    jvm = jpype.getDefaultJVMPath()

classpath = "-Djava.class.path=%s" % ":".join(
    [pkg_resources.resource_filename(__name__, 'assets/jars/quasar-latest.jar'), #'jars/quasar-1.0.jar'
    ])

if not jpype.isJVMStarted():
    jpype.startJVM(jvm, "-ea", '-Xmx128g', '-Xss128g', '-Djna.nosys=true', classpath)

# define some java classes for direct use
quasar = jpype.JPackage('com.quantego.quasar')
