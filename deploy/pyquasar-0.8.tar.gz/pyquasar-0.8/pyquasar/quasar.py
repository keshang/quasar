from __future__ import print_function
import jpype
import platform
import glob
import os
import sys
import pkg_resources

if platform.system() == 'Darwin':
    jvm = glob.glob('/Library/Java/JavaVirtualMachines/jdk1.7.*.jdk/Contents/MacOS/libjli.dylib')
    jvm.reverse() #newest first
    jvm = jvm[0]
else:
    jvm = jpype.getDefaultJVMPath()

assert 'QUASAR_JAR' in os.environ, 'Environment variable QUASAR_JAR not set. Should contain absolute path to QUASAR Jar.'
jar = os.path.expanduser(os.environ['QUASAR_JAR'])
assert os.path.exists(jar), 'Jar file does not exist.'
classpath = "-Djava.class.path=%s" % jar

# classpath = "-Djava.class.path=%s" % ":".join(
#     [pkg_resources.resource_filename(__name__, 'assets/jars/quasar-latest.jar'), #'jars/quasar-1.0.jar'
#     ])

if not jpype.isJVMStarted():
    jpype.startJVM(jvm, "-ea", '-Xmx128g', '-Xss128g', '-Djna.nosys=true', classpath, '-Djava.library.path=/usr/lib/jni/:%s' % os.path.expanduser('~/Library/Java/Extensions'))

# define some java classes for direct use
quasar = jpype.JPackage('com.quantego.quasar')
