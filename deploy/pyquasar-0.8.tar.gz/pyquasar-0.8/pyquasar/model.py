"""
The module *model* holds all objects that are required to formulate a stochastic optimization problem.
"""

from __future__ import print_function
import warnings
from .process.markov_process import MarkovProcess

import jpype


class DecisionProblem(object):
    """The DecisionProblem holds the model formulation of a stochastic optimization problem.

    Although QUASAR rests on dynamic programming techniques, the decision problem can be formulated just like a
    conventional linear program. Any model coefficient or right-hand-side can be modeled as a random variable
    that is defined through a MarkovProcess.

    Decision variables can be added by one by one by calling add_variable() or in tuples by calling add_variables().
    Constraints are added using add_constraint() or by using +=.
    An objective function can be either created implicitly by defining an objective
    coefficient with each DecisionVariable, or by creating an Expression and
    using set_objective or +=. An Expression that is added to the DecisionProblem using += is automatically
    added to the objective function but does not replace it.

    If a DecisionVariable from different stages are used in the same Relation, it is recommended that the
    DecisionVariable with the smaller time index provides an upper bound.

    Arguments:
        name (str, optional) -- name of decision problem

    Keyword arguments:
        minimize (bool, optional) -- Solve as minimization problem. (Default: False)

    Example:
        >>> model = DecisionProblem("MyProblem", minimize = True)
        >>> x = model.add_variable(stage=0, name="x")
        >>> model += 4*x
        >>> model += x >= 10
    """

    def __init__(self, *args, **kwargs):
        if len(args)>0:
            if type(args[0]) is str:
                self.name = args[0]
        else:
            self.name = "DecisionProblem"
        self.cls = 'com.quantego.quasar.model.DecisionProblem'
        self._inner = jpype.JClass(self.cls)(self.name)

        if 'minimize' in kwargs:
            minimize = kwargs['minimize']
            if type(minimize) is not bool:
                raise TypeError('Argument minimize must be True or False.')
            else:
                if minimize:
                    self._inner.minimize()

    def add_variable(self, stage, name=None, lb=None, ub=None, obj=None):
        """Add a single *DecisionVariable* to a *DecisionProblem*.

        If a name is provided for the variable, the solution will be stored during simulation.

        Arguments:
            stage (int): stage to add variables to
            var (str): variable names

        Returns:
            DecisionVariable

        Example:
            >>> variable= model.add_variables(stage=2, name="x", lb=0, ub=50)
        """
        if type(stage) is not int:
            raise TypeError('Type %s. Allowed type(s) for stage: int.'%type(stage))
        if name is None:
            java_var = self._inner.addVariable(stage)
        else:
            if type(name) is str:
                java_var = self._inner.addVariable(stage,name)
            else:
                raise TypeError('Type %s. Allowed type(s) for name: str.'%type(name))
        if lb is not None:
            if type(lb) is float or type(lb) is int:
                java_var.lb(float(lb))
            else:
                raise TypeError('Type %s. Allowed type(s) for lb: int, float.'%type(lb))
        if ub is not None:
            if type(ub) is float or type(ub) is int:
                java_var.ub(float(ub))
            else:
                raise TypeError('Type %s. Allowed type(s) for ub: int, float.'%type(ub))
        if obj is not None:
            if type(ub) is float or type(ub) is int:
                java_var.obj(float(obj))
            elif type(ub) is RandomVariable:
                java_var.obj(obj._inner)
            else:
                raise TypeError('Type %s. Allowed type(s) for ub: int, float, RandomVariable.'%type(obj))
        new_var = DecisionVariable(java_var)
        #self._inner.addVariable(new_var._inner)
        return new_var

    def addVariable(self, stage, name, lb=None, ub=None, obj=None):
        warnings.warn("Function addVariable is deprecated. Use add_variable instead.",category=DeprecationWarning)
        return self.add_variable(stage, name, lb, ub, obj)

    def add_variables(self, stage, *args, **kwargs):
        """Add multiple *DecisionVariables* to a *DecisionProblem*.

        If a names are provided for the variables, their solutions will be stored during simulation.

        Arguments:
            stage (int): stage to add variables to
            vars (multiple str): One or more variable names

        Returns:
            A tuple of DecisionVariable.

        Examples:
            >>> inject, withdraw, content = model.add_variables(t,"inject","withdraw","storage")
            >>> inject, withdraw, content = model.add_variables(t, num_vars=3)
        """
        names = args
        if 'num_vars' in kwargs:
            num_vars = kwargs['num_vars']
        else:
            if len(kwargs) > 0:
                raise Exception("Unknown keys: %s"%''.join(kwargs))
            num_vars = len(names)
        if type(num_vars) is not int:
            raise TypeError('Type %s. Allowed type(s) for num_vars: int.'%type(num_vars))
        if num_vars != len(names) and len(names) > 0:
            raise IndexError("Length of names arguments must be equal to num_vars.")
        if num_vars==len(names):
            new_vars = [self.add_variable(stage, name=name) for name in names]
        else:
            new_vars = [self.add_variable(stage) for i in range(num_vars)]
        #[self._inner.addVariable(var._inner) for var in new_vars]

        if num_vars == 1:
            return new_vars[0]
        else:
            return new_vars

    def addVariables(self, stage, *names):
        warnings.warn("Function addVariables is deprecated. Use add_variables instead.",category=DeprecationWarning)
        return self.add_variables(stage, *names)

    def maximize(self):
        """
        Define the DecisionProblem as a maximization problem.
        """
        self._inner.maximize()
        return self

    def minimize(self):
        """
        Define the DecisionProblem as a minimization problem.
        """
        self._inner.minimize()
        return self

    def to_lp_string(self,process):
        '''
        Return the model formulation in lp-format for export to other solvers.

        Random variables are replaced by sample realizations of the given MarkovProcess.

        Arguments:
            markov_process (MarkovProcess) -- A MarkovProcess that defines the random variables.

        Returns:
            The model formulation in lp format as string.
        '''
        if not isinstance(process, MarkovProcess):
            raise Exception("Type %s. The process is not of type MarkovProcess."%type(process))
        return self._inner.toString(process._inner)

    def to_lp_file(self, process):
        '''
        Store the model formulation as an lp-file for export to other solvers.

        Random variables are replaced by sample realizations of the given MarkovProcess.

        Arguments:
            markov_process (MarkovProcess) -- A MarkovProcess that defines the random variables.

        '''
        if not isinstance(process, MarkovProcess):
            raise Exception("Type %s. The process is not of type MarkovProcess."%type(process))
        self._inner.storeLP(process._inner)

    def num_stages(self):
        '''
        Returns:
            The number of stages of the DecisionProblem.
        '''
        return self._inner.getNumStages()

    def add_constraint(self, relation, name=None):
        '''
        Add a Relation as a constraint to the DecisionProblem.

        If a name is provided for the constraint, the dual solution will be stored during simulation.

        Example:
            >>> add_constraint( x + y <= 10 )
        '''
        if type(relation) is Relation:
            ctr = self._inner.addConstraint(relation._inner)
            if name is not None:
                if type(name) is str:
                    ctr.storeSolution(name)
                else:
                    raise TypeError('Type %s. Allowed type(s) for name: str.'%type(name))
        else:
            raise TypeError('Type %s. Allowed type(s) to represent a constraint: Relation.'%type(relation))

    def set_objective(self, expression):
        '''
        Set an Expression as objective function of the DecisionProblem

        Example:
            >>> set_objective( x + y )
        '''
        if type(expression) is Expression:
            self._inner.setObjective(expression._inner)
        else:
            raise TypeError('Type %s. Allowed type(s) to represent an objective function: Expression.'%type(expression))

    def __iadd__(self, term):
        # """
        # Add an Expression, Relation or Bound to a DecisionProblem. Relations become constraints, expressions are
        # added to the objective function. Bounds are added to the DecisionVariable.
        #
        # Returns:
        #     The DecisionProblem
        #
        # Example:
        #     >>> model += x + y <= 10
        #     (add a constraint)
        #     >>> model += x + y
        #     (add to the objective function)
        # """
        if type(term) is Relation:
            self.add_constraint(term)
            return self
        if type(term) is Expression:
            self._inner.addToObjective(term._inner)
            return self
        elif type(term) is DecisionVariable:
            return self.__iadd__(Expression().__add__(term))
        elif type(term) is Bound:
            term._make_bound()
            return self
        else:
            raise TypeError('Type %s. Allowed type(s) to add to a DecisionProblem: Expression, Relation.'%type(term))

    def __repr__(self):
        return self._inner.toString()


class Expression(object):
    '''A linear function of decision variables multiplied real values or random variables plus a constant value.

    Valid expressions can be created using addition with other expressions, numbers, or RandomVariable, as well as
    multiplication with numbers or RandomVariable. Expressions cannot be divided by anything but a number.

    Arguments:
    terms -- {variable : coefficient, ... }

    Example:
         >>> (x + 3*y) / 4
         >>> (x + rand("price")*y) / 4)
    '''
    def __init__(self):
        self.cls = 'com.quantego.quasar.model.Expression'
        self._inner = jpype.JClass(self.cls)()

    def __add__(self, other):
        e = Expression()
        e._inner.add(self._inner)
        if type(other) is Expression or type(other) is DecisionVariable or type(other) is RandomVariable:
            e._inner.add(other._inner)
            return e
        elif type(other) is float or type(other) is int:
            e._inner.add(float(other))
            return e
        raise TypeError('Type: %s. Allowed type(s) for addition: int, float, Expression, DecisionVariable, RandomVariable.'%type(other))

    def __mul__(self, other):
        e = Expression()
        e._inner.add(self._inner)
        if type(other) is float or type(other) is int:
            e._inner.mul(float(other))
            return e
        elif type(other) is RandomVariable:
            e._inner.mul(other._inner)
            return e
        raise TypeError('Type %s. Allowed type(s) for multiplication: int, float, RandomVariable.'%type(other))

    def __sub__(self, other):
        # x - y
        # x - 2
        return self.__add__(other.__neg__())

    def __rsub__(self, other):
        # 1 - x is the same as -x + 1
        return self.__neg__().__add__(other)

    def __div__(self, other):
        if type(other) is int or type(other) is float:
            # x / 2
            return self.__mul__(1.0/other)
        return TypeError('Type %s. Allowed type(s) for division: int, float.'%type(other))

    def __neg__(self):
        # -(x * y)
        return self.__mul__(-1)

    def __pos__(self):
        # +(x * y)
        return self

    def __pow__(self, x):
        return NotImplemented

    __rdiv__ = __pow__
    __rtruediv__ = __pow__
    __radd__ = __add__
    __rmul__ = __mul__
    __truediv__ = __div__

    def __eq__(self, other):
        return Relation.eq(self, other)

    def __le__(self, other):
        return Relation.le(self, other)

    def __ge__(self, other):
        return Relation.ge(self, other)

    def __repr__(self):
        return self._inner.toString()


class DecisionVariable(object):
    """A decision variable that can be used as part of an DecisionProblem.

    Example:
         >>> stage = 2
         >>> x = model.add_variable(stage, name="x")
    """

    def __init__(self, java_var):
        #self.cls = 'com.quantego.quasar.model.DecisionVariable'
        #self.name = name
        self._inner = java_var
        #if lb is not None:
        #    self._inner.lb(float(lb))
        #if ub is not None:
        #    self._inner.ub(float(ub))
        #if obj is not None:
        #    self._inner.obj(float(obj))

    def __repr__(self):
        return "%s_%d"%(self._inner.getName(),self._inner.getStage())

    def __add__(self, other):
        return Expression().__add__(self).__add__(other)

    def __mul__(self, other):
        return Expression().__add__(self).__mul__(other)

    def __sub__(self, other):
        # x - y
        # x - 2
        return self.__add__(other.__neg__())

    def __rsub__(self, other):
        # 1 - x is the same as -x + 1
        return self.__neg__().__add__(other)

    def __div__(self, other):
        if type(other) is int or type(other) is float:
            # x / 2
            return self.__mul__(1.0/other)
        return TypeError('Type %s. Allowed type(s) for division: int, float.'%type(other))

    def __neg__(self):
        # -(x * y)
        return self.__mul__(-1)

    def __pos__(self):
        # +(x * y)
        return self

    def __pow__(self, x):
        return NotImplemented

    __rdiv__ = __pow__
    __rtruediv__ = __pow__
    __radd__ = __add__
    __rmul__ = __mul__
    __truediv__ = __div__

    def __le__(self, other):
        if type(other) is float or type(other) is int:
            return Bound(self._inner,ub=other)
        else:
            return Relation.le(1.0*self, other)

    def __ge__(self, other):
        if type(other) is float or type(other) is int:
            return Bound(self._inner,lb=other)
        else:
            return Relation.ge(1.0*self, other)

    def __eq__(self, other):
        if type(other) is float or type(other) is int:
            return Bound(self._inner,lb=other,ub=other)
        else:
            return Relation.eq(1.0*self, other)

class Bound(object):
    """A bound of a DecisionVariable. Bounds can only be real values.

    Example:
            >>> model += variable <= 50
            >>> model += variable >= 10
            >>> model += (10 <= variable) <= 50
            (mind the brackets)
    """
    _lb = None
    _ub = None

    def __init__(self, var, lb=None, ub=None):
        self._inner = var
        if lb is not None:
            if not (type(lb) is float or type(lb) is int):
                raise TypeError('Type %s. Allowed type(s) for bounds: int, float. Use Relation instead.'%type(lb))
            self._lb = lb
        if ub is not None:
            if not (type(ub) is float or type(ub) is int):
                raise TypeError('Type %s. Allowed type(s) for bounds: int, float. Use Relation instead.'%type(ub))
            self._ub = ub

    def _make_bound(self):
        if self._lb is not None:
            self._inner.lb(float(self._lb))
        if self._ub is not None:
            self._inner.ub(float(self._ub))

    def __repr__(self):
        if self._ub is None:
            return '%s >= %s'%(self._inner.getName(), self._lb)
        if self._lb is None:
            return '%s <= %s'%(self._inner.getName(), self._ub)
        if float(self._lb) == float(self._ub):
            return '%s == %s'%(self._inner.getName(), self._ub)
        return '%s <= %s <= %s'%(self._lb, self._inner.getName(), self._ub)

    def __le__(self, other):
        return Bound(self._inner, lb=self._lb, ub=other)

    def __ge__(self, other):
        return Bound(self._inner, lb=other, ub=self._ub)

    def __eq__(self, other):
        return Bound(self._inner, lb=other, ub=other)


class RandomVariable(object):
    """A random variable as an affine function of one or more state variables which are defined by a given name.

    Examples:
        >>> RandomVariable("Demand")
        >>> 0.99*RandomVariable("Price")
        >>> 3.6*RandomVariable("Inflow") + 10
    """

    def __init__(self, name):
        self.cls = 'com.quantego.quasar.model.RandomVariable'
        self.name = name
        self._inner = jpype.JClass(self.cls)(self.name)

    def __add__(self, other):
        if type(other) is float or type(other) is int:
            r = RandomVariable(self.name)
            r._inner = self._inner.clone()
            r._inner = r._inner.add(float(other))
            return r
        elif type(other) is RandomVariable:
            r = RandomVariable(self.name)
            r._inner = self._inner.clone()
            r._inner = r._inner.add(1.0,other._inner)
            return r
        elif type(other) is DecisionVariable:
            return Expression().__add__(self).__add__(other)
        elif type(other) is Expression:
            return other+self
        raise TypeError('Type %s. Allowed type(s) for addition: int, float, DecisionVariable, Expression.'%type(other))

    def __mul__(self, other):
        if type(other) is float or type(other) is int:
            # RandomVariable.mul(float)
            r = RandomVariable(self.name)
            r._inner = self._inner.clone()
            r._inner = r._inner.mul(float(other))
            return r
        elif type(other) is DecisionVariable:
            return Expression().__add__(other).__mul__(self)
        elif type(other) is Expression:
            return other*self
        raise TypeError('Type: %s. Allowed type(s) for multiplication: int, float, DecisionVariable, Expression.'%type(other))

    def __sub__(self, other):
        # x - y
        # x - 2
        return self.__add__(other.__neg__())

    def __rsub__(self, other):
        # 1 - x is the same as -x + 1
        return self.__neg__().__add__(other)

    def __div__(self, other):
        if type(other) is int or type(other) is float:
            # x / 2
            return self.__mul__(1.0/other)
        return TypeError('Type %s. Allowed type(s) for division: int, float.'%type(other))

    def __neg__(self):
        # -(x * y)
        return self.__mul__(-1)

    def __pos__(self):
        # +(x * y)
        return self

    def __pow__(self, x):
        return NotImplemented

    __rdiv__ = __pow__
    __rtruediv__ = __pow__
    __radd__ = __add__
    __rmul__ = __mul__
    __truediv__ = __div__

    def __repr__(self):
        return self._inner.toString()

    def __eq__(self, other):
        return Expression().__add__(self) == other

    def __le__(self, other):
        return Expression().__add__(self) <= other

    def __ge__(self, other):
        return Expression().__add__(self) >= other

class Relation(object):
    """A binary relation between two Expression objects.

    Example:
        >>> x + y <= z + 10
    """
    def __init__(self):
        self._inner = None

    @classmethod
    def eq(cls, lhs, rhs):
        java_lhs, java_rhs = Relation._validate(lhs,rhs)
        relation = Relation()
        relation._inner = java_lhs.__eq__(java_rhs)
        return relation

    @classmethod
    def le(cls, lhs, rhs):
        java_lhs, java_rhs = Relation._validate(lhs,rhs)
        relation = Relation()
        relation._inner = java_lhs.__le__(java_rhs)
        return relation

    @classmethod
    def ge(cls, lhs, rhs):
        java_lhs, java_rhs = Relation._validate(lhs,rhs)
        relation = Relation()
        relation._inner = java_lhs.__ge__(java_rhs)
        return relation

    def __repr__(self):
        return self._inner.toString()

    @classmethod
    def _validate(cls,lhs,rhs):
        if type(lhs) is float or type(lhs) is int:
            lhs = Expression()*lhs
        if type(lhs) is not Expression:
            raise TypeError('Type %s. Allowed type(s) for lhs: int, float, DecisionVariable, RandomVariable, Expression.'%type(lhs))
        java_lhs = lhs._inner
        if type(rhs) is Expression:
            java_rhs = rhs._inner
        elif type(rhs) is DecisionVariable:
            java_rhs = rhs._inner
        elif type(rhs) is RandomVariable:
            java_rhs = rhs._inner
        elif type(rhs) is int or type(rhs) is float:
            java_rhs = float(rhs)
        else:
            raise TypeError('Type %s. Allowed type(s) for rhs: int, float, DecisionVariable, RandomVariable, Expression.'%type(rhs))
        return java_lhs, java_rhs