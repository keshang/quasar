"""
The module *lattice* holds the Lattice class which is required by the DynamicOptimizer to solve a DecisionProblem.
"""

import jpype
from sklearn.utils.validation import check_array, as_float_array

from pyquasar.process import MarkovProcess


class Lattice(MarkovProcess):
    """A Lattice is a discrete MarkovProcess that is required by DynamicOptimizer to solve a DecisionProblem.

    Different scenario reduction techniques apply to determine a representative state for each node of the lattice.</br>
    * RANDOM: Nodes of the lattice are selected randomly. The transition matrix is constructed using maximum likelihood.</br>
    * MARGINAL_KMEANS: Nodes of the lattice are selected such that the distance between the sample and the scenarios is minimized. The transition matrix is constructed by updating the edge weights between nearest neighbors.</br>
    * MARGINAL_FUZZY: Nodes of the lattice are selected such that the distance between the sample and the scenarios is minimized. The transition matrix is constructed by using a fuzzy approach that updates all edge weights.
    * This approach is most useful when a sample if read from a CSV where only few observations are available and counting nearest neighbors would yield to transition probabilities with too little support.</br>
    * CONDITIONAL_KMEANS: Nodes of the lattice are built sequentially based on the filtration defined by the unconditional probability of all nodes of the previous state. This approach requires that state transition can be simulated. Do not use a {@link} TimeSeriesSample.</br>
    * Note that each node is still provided a weight which is defined by the transition probabilities as well as transition probabilities of predecessor nodes.

    Arguments:
    process -- MarkovProcess
    num_stages -- number of stages

    Keyword arguments:
        distance (str): Provide a list of distances measures used to determine the nearest node for a given state for each stage. Possible options: MANHATTAN, EUCLIDEAN, SQUARED, MAXIMUM. (Default = SQUARED)
        scenario_reduction_method (str): Select the scenario reduction technique which is used to determine a representative {@link} State for each node of the lattice. Possible options: RANDOM, MARGINAL_KMEANS,CONDITIONAL_KMEANS, MARGINAL_FUZZY. (Default = RANDOM)
        growth_rate (str): Growth rate of the number of nodes per stage. Possible options: LINEAR, SQUARE_ROOT, CONSTANT. (Default = CONSTANT)
        sample_size (int): Sample size used for maximum likelihood estimation. (Default ist scaled automatically)
        num_threads: Number of simultaneous threads used for computation. (Default = Number of (virtual cores)
        weights (list of float): Weight of each state variables. A nested list can be provided with different weights for each stage. (Default = [1]*dim)
        num_nodes: Average number of nodes available at each stage. (Default = 10)
        match_means (bool): Tries to match the next state mean of the Markov process with the next state mean of the lattice by recalibrating the transition probabilities. (Default = False)
        state_variables (list of str): Defines all relevant state variables and sets the weight of all other state variables equal to zero. (Default = [])
        generate_weights (int, optional): Weights will be determined automatically using the standard deviation of the marginal distributions. (Default = None)
    """

    @staticmethod
    def _check_kwargs(_known_keys, kwargs):
        if not _known_keys.issuperset(kwargs.keys()):
            unknown_keys = set()
            for key in kwargs:
                if not _known_keys.__contains__(key):
                    unknown_keys.add(key)
            raise Exception("Unknown keys: %s"%''.join(unknown_keys))

    def __init__(self, process=None, num_stages=2, num_nodes=10, **kwargs):
        if process is not None:
            self._build_lattice(process, num_stages, num_nodes, kwargs)


    def _build_lattice(self, process, num_stages, num_nodes, kwargs):
        #process = kwargs.get('process')
        if not isinstance(process, MarkovProcess):
            raise Exception("Type %s. The process is not of type MarkovProcess."%type(process))
        #num_stages = kwargs.get('num_stages')
        #num_nodes = kwargs.get('num_nodes')
        #check if all the keys are valid
        known_keys = {'process', 'num_stages', 'num_nodes', 'distance', 'scenario_reduction_method', 'growth_rate',
                      'sample_size', 'weights', 'num_nodes', 'num_threads', 'match_means',
                      'state_variables', 'generate_weights'}
        self._check_kwargs(known_keys, kwargs)
        #create an instance of the java builder
        lattice_builder = jpype.JClass('com.quantego.quasar.stochastic.lattice.LatticeBuilder')
        DISTANCE = jpype.JClass("com.quantego.quasar.tools.math.DISTANCE")
        SCENRED = jpype.JClass("com.quantego.quasar.stochastic.lattice.SCENRED")
        GROWTHRATE = jpype.JClass("com.quantego.quasar.stochastic.lattice.GROWTHRATE")
        builder = lattice_builder.createLatticeFromSimulation(process._inner, num_stages, num_nodes)
        #call the corresponding builder function if kwargs have the right key
        if 'scenario_reduction_method' in kwargs:
            builder.scenarioReductionMethod(eval('SCENRED.' + kwargs['scenario_reduction_method']))
        if 'growth_rate' in kwargs:
            builder.avgNumNodes(num_nodes, eval('GROWTHRATE.' + kwargs['growth_rate']))
        if 'distance' in kwargs:
            builder.distance(eval('DISTANCE.' + kwargs['distance']))
        if 'weights' in kwargs:
            builder.weights(kwargs.get('weights'))
        if 'num_threads' in kwargs:
            builder.numberOfThreads(kwargs['num_threads'])
        if 'sample_size' in kwargs:
            builder.sampleSize(kwargs['sample_size'])
        if 'match_means' in kwargs:
            builder.matchMeans()
        if 'state_variables' in kwargs:
            builder.markovianStateVariables(kwargs['state_variables'])
        if 'generate_weights' in kwargs:
            builder.generateWeights(kwargs['generate_weights'])
        self._inner = builder.build()

    @classmethod
    def combine(cls,lattice1,lattice2):
        """Combine two lattices by creating a new lattice that forms the cross product of the two lattices.

        Both lattices must have the same number of stages.

        Arguments:
        lattice1 -- first lattice
        lattice2 -- second lattice
        """
        lattice = Lattice()
        lattice_builder = jpype.JClass('com.quantego.quasar.stochastic.lattice.SparseLattice')
        lattice._inner = lattice_builder.combine(lattice1._inner,lattice2._inner)
        return lattice

    @classmethod
    def from_csv(cls, prefix, distance='SQUARED', seed=None):
        """Create a new lattice from three CSV files, *_stages.csv, *_nodes.csv, *_transitions.csv.

        Arguments:
        prefix -- prefix of the file names
        """
        lattice = Lattice()
        lattice_builder = jpype.JClass('com.quantego.quasar.stochastic.lattice.LatticeBuilder')
        if seed is not None or distance is not 'SQUARED':
            DISTANCE = DISTANCE = jpype.JClass("com.quantego.quasar.tools.math.DISTANCE")
            distance = eval('DISTANCE.' + distance)
            if seed is not None:
                generator = jpype.JClass("java.util.Random")(long(seed))
            else:
                generator = jpype.JClass("java.util.Random")()
            lattice._inner = lattice_builder.createLatticeFromCSV(prefix, distance, generator)
        else:
            lattice._inner = lattice_builder.createLatticeFromCSV(prefix)
        return lattice

    @classmethod
    def from_data(cls, data, state_variable_names, num_stages, num_nodes, **kwargs):
        """Estimate a lattice from a sample of observations of a (multivariate) time series.

        Arguments:
        data -- (n x m)-matrix of sample data with n observations of m variables
        state_variable_names -- names of the state variables
        num_stages -- number of stages
        num_nodes -- number of nodes per stage

        Keyword arguments:
            initial_state (str): Define the initial state (root node) of the lattice. If no initial state is selected. The lattice will have multiple root nodes with probability corresponding to the steady-state probability of the estimated Markov chain. (Default = random)
            num_passes (int): Determines the number of passes of the competitive learning algorithm over sample. (Default = auto)
            distance (str): Distance measure and weights to be used for nearest neighbor. (Default = SQUARED)
            fuzzy_transitions (bool): Instead of counting transitions between nearest neighbors the transition matrix is constructed using a fuzzy approach that updates possible transitions with a distance based score. The score is identical to the grades scheme of Fuzzy C-means clustering. (Default = False)
            periodic (int): Fit a lattice with periodic dynamics. Transitions are selected from a given time window which must be strictly smaller than the cycle. The number of stages of the lattice remains unaffected from the choice of the cycle length. (Default = 1)
            window_size (int): Increases the number of observations available for each period by using a moving window of observations for each period. (Default = 0)
            skip (int): Skip the first n periods during simulation. (Default = 0)
            transform_states (matrix of float): Transform the k-dimensional state vectors of the estimated lattice to a higher m dimensional state by multiplying each vector with the given matrix. (Default = None)
            transform_names (list of str): Variable names of the m transformed state variables (Default = None)
            increase_transition_frequency (int): Increase the transition frequency by a given factor. (Default = 1)
        """
        known_keys = {'initial_state', 'num_passes', 'num_nodes', 'distance', 'weights', 'fuzzy_transitions', 'periodic', 'skip',
                      'transform_states', 'transform_names', 'increase_transition_frequency', 'window_size'}
        Lattice._check_kwargs(known_keys,kwargs)
        lattice = Lattice()
        lattice_builder = jpype.JClass('com.quantego.quasar.stochastic.lattice.DataDrivenLattice')
        DISTANCE = jpype.JClass("com.quantego.quasar.tools.math.DISTANCE")
        #verify input data
        data = check_array(data)
        data = as_float_array(data, copy=False).tolist()
        builder = lattice_builder.createLatticeFromData(data, state_variable_names, num_stages, num_nodes)
        if 'periodic' in kwargs:
            if 'window_size' in kwargs:
                builder.periodic(kwargs['periodic'],kwargs['window_size'])
            else:
                builder.periodic(kwargs['periodic'],0)
        if 'fuzzy_transitions' in kwargs:
            builder.fuzzyTransitions()
        if 'skip' in kwargs:
            builder.skip(kwargs['skip'])
        if 'num_passes' in kwargs:
            builder.numPasses(kwargs['num_passes'])
        if 'initial_state' in kwargs:
            init_state = kwargs['initial_state']
            data = check_array(init_state)
            data = as_float_array(init_state, copy=False).tolist()
            if 'transform_names' in kwargs:
                if len(init_state) < len(kwargs['transform_names']):
                    raise IndexError('The initial state has the wrong dimensionality.')
            else:
                if len(init_state) < len(state_variable_names):
                    raise IndexError('The initial state has the wrong dimensionality.')
            builder.initialState(data)
        if 'distance' in kwargs or 'weights' in kwargs:
            if 'weights' not in kwargs or 'distance' not in kwargs:
                raise KeyError('Distance measure and list of weights required.')
            builder.distanceMeasure(eval('DISTANCE.' + kwargs['distance']),kwargs['weights'])
        if 'transform_states' in kwargs and 'transform_names' in kwargs:
            builder.transformStates(kwargs['transform_states'],kwargs['transform_names'])
        if 'increase_transition_frequency' in kwargs:
            builder.increaseTransitionFrequency(kwargs['increase_transition_frequency'])
        lattice._inner = builder.build()
        return lattice

    def to_csv(self, prefix):
        """Store the lattice in three CSV files, *_stages.csv, *_nodes.csv, and *_transitions.csv.

        Arguments:
        prefix -- prefix of the file names
        """
        self._inner.storeCSV(prefix)

    def compute_forecast(self):
        """
        Store the expected values of all future state variables with each node of the lattice.
        """
        self._inner.computeForecasts()

    def num_nodes(self):
        """
        Return the total number of nodes of the lattice.
        """
        return self._inner.getNumNodes()

    def num_nodes_stage(self, stage):
        """Return the total number of nodes of the lattice at the given stage.

        Arguments:
        stage -- stage of the lattice
        """
        return self._inner.getNodes(stage).size()

    def num_stages(self):
        """Return the total number of stages of the lattice.
        """
        return self._inner.getNumStages()

    def exp(self):
        """
        Apply exponentiation to all elements of this lattice.
        """
        self._inner.exp()

    def log(self):
        """Apply log transformation to all elements of this lattice.
        """
        self._inner.log()

    def arcsinh(self):
        """Apply inverse hyperbolic sine transformation to all elements of this lattice.
        """
        self._inner.arcsinh()

    def sinh(self):
        """Apply hyperbolic sine transformation to all elements of this lattice.
        """
        self._inner.sinh()

    def mul(self,array):
        """Multiply the states of the lattice with the given values.

        If a two-dim array is provided, the given values will be multiplied with all state vectors at one stage.
        If a three-dim array is provided, the vectors will be multiplied with the states associated with the individual
        nodes.

        Arguments:
        matrix -- An array with rows equal to the number of stages.
        """
        self._inner.mul(array)

    def add(self,array):
        """Add the given values to the states of the lattice.

        If a two-dim array is provided, the given values will be added to all state vectors at one stage. If a three-dim
        array is provided, the vectors will be added to the states associated with the individual nodes.

        Arguments:
        matrix -- An array with rows equal to the number of stages.
        """
        self._inner.add(array)

