import jpype
import warnings
from .markov_process import MarkovProcess

class ARModel(MarkovProcess):
    """The autoregressive (AR) model as a MarkovProcess.

    State variable realizations of a sample path can be accessed by
    the given name 'varname', while independent variables of higher-order lags
    (>2) can be accessed via 'varname:t'. Independent variables at higher order
    lags can therefore be used as model parameters.

    Without further information, the initial state of the process is assumed to be zero, which
    will likely induce an initialization bias. The class provides two means
    to avoid bias. Either, the user specifies a warm-up phase, or, the user
    provides a set of initial values.

    Arguments:
        name (str): Name of the state variable
        mu (float): Constant term
        sigma (float): Standard deviation of the error term
        ar_coefficients (list of float): AR coefficients

    Keyword Args:
        initial_state: (list of float, optional): Initial state of the AR model with the current state as first
            element: [t,t-1,...,t-p]. The length of the vector must equal the number of lags.
        log_transform: Log-transform states before each transition to obtain a geometric process
        truncate (list of float, optional): Truncate at [min,max]
        truncate_zero (bool, optional): Truncate at zero
        warm_up_phase (int, optional): Number of state transitions to overcome the initial transient phase.


    Returns:
        MarkovProcess: An instance of MarkovProcess

    Example:
        >>> process = ARModel("Demand", 25, 5, [0.8,-0.3], initial_state=[12,25], truncate_zero=True)
    """

    def __init__(self, name, constant, sigma, ar_coefficients,
                 initial_state=None,
                 log_transform=None,
                 truncate_zero=False,
                 truncate=None,
                 warm_up_phase=None):
        armodel = jpype.JClass('com.quantego.quasar.stochastic.process.univariate.ARModel')
        coefficients = [float(c) for c in ar_coefficients]
        self._inner = armodel.create(str(name), float(constant), float(sigma), coefficients)

        if initial_state:
            if len(initial_state) < len(ar_coefficients): # TODO: rewrite to asserts
                raise IndexError("Number of initial states must equal the number of lags.")
            self._inner.initialState([float(c) for c in initial_state])
        if truncate:
            try:
                self._inner.truncate(float(truncate[0]),float(truncate[1]))
            except IndexError:
                raise IndexError("truncate has two arguments.")
            except:
                raise
        if truncate_zero:
            self._inner.truncateZero()
        if warm_up_phase:
            self._inner.warmUpPhase(int(warm_up_phase))
        if log_transform:
            self._inner.logtransform()


class ARMAModel(MarkovProcess):
    """The autoregressive-moving-average (ARMA) model as a MarkovProcess.

    State variable realizations of a sample path can be accessed by
    the given name 'varname', while independent variables of higher-order lags
    (>2) can be accessed via 'varname:t'. Independent variables at higher order
    lags can therefore be used as model parameters. Errors can be accessed via 'error:t'.

    Without further information, the initial state of the process is assumed to be zero, which
    will likely induce an initialization bias. The class provides two means
    to avoid bias. Either, the user specifies a warm-up phase, or, the user
    provides a set of initial values.

    Arguments:
        name (str): Name of the state variable
        mu (float): Constant term
        sigma (float): Standard deviation of the error term
        ar_coefficients (list of float): AR coefficients
        ma_coefficients (list of float): MA coefficients

    Keyword Args:
        initial_state: (list of float, optional): Initial state of the AR model with the current state as first
            element: [t,t-1,...,t-p]. The length of the vector must equal the number of lags.
        initial_error: (list of float, optional): Initial error of the MA model with the current error as first
            element: [t,t-1,...,t-q]. The length of the vector must equal the number of lags.
        log_transform (bool, optional): Log-transform states before each transition to obtain a geometric process
        truncate (list of float, optional): Truncate at [min,max]
        truncate_zero (bool, optional): Truncate at zero
        warm_up_phase (int, optional): Number of state transitions to overcome the initial transient phase.

    Returns:
        MarkovProcess: An instance of MarkovProcess

    Example:
         >>> process = ARMAModel("Demand", 25, 5, [0.8], [0.2], initial_state=[12], initial_error=[0.5])
    """
    def __init__(self, name, constant, sigma, ar_coefficients, ma_coefficients,
                 initial_state=None,
                 initial_error=None,
                 log_transform=None,
                 truncate_zero=False,
                 truncate=None,
                 warm_up_phase=None):
        armamodel = jpype.JClass('com.quantego.quasar.stochastic.process.univariate.ARMAModel')
        ar_coefficients = [float(c) for c in ar_coefficients]
        ma_coefficients = [float(c) for c in ma_coefficients]
        self._inner = armamodel.create(name, float(constant), float(sigma), ar_coefficients, ma_coefficients)

        if initial_state:
            if len(initial_state) < len(ar_coefficients):
                raise IndexError("Number of initial states must equal the number of lags of the AR part.")
            self._inner.initialState([float(c) for c in initial_state])
        if initial_error:
            if len(initial_error) < len(ma_coefficients):
                raise IndexError("Number of initial errors must equal the number of lags of the MA part.")
            self._inner.initialError([float(c) for c in initial_error])
        if truncate:
            try:
                self._inner.truncate(float(truncate[0]),float(truncate[1]))
            except IndexError:
                raise IndexError("truncate has two arguments.")
            except:
                raise
        if truncate_zero:
            self._inner.truncateZero()
        if warm_up_phase:
            self._inner.warmUpPhase(int(warm_up_phase))
        if log_transform:
            self._inner.logtransform()

class GBM(MarkovProcess):
    """Geometric Brownian motion (GBM) in discrete time.

    Arguments:
        name (str): name of the state variable
        initial_state (float): initial value (do not log-transform)
        drift (float): drift
        volatility (float): volatility

    Returns:
        MarkovProcess: An instance of MarkovProcess

    Example:
            >>> process = UnivariateGBM("price", initial_state=11.5, drift=0.0, volatility=0.3)
    """
    def __init__(self, name, initial_state, drift, volatility):
        gbm = jpype.JClass('com.quantego.quasar.stochastic.process.univariate.UnivariateGBM')
        self._inner = gbm.create(str(name), float(initial_state), float(drift), float(volatility))

UnivariateGBM = GBM


class StochasticTrendModel(MarkovProcess):

    def __init__(self):
        raise NotImplementedError("Please use the from_data() method.")

    def _init_from_df(self, df, name, cycle_length, log_transform, smoothing_method, warm_up_phase, truncate,
                      bootstrap_errors, bandwidth, heavy_tailed, initial_stage, initial_state):

        builder = jpype.JClass('com.quantego.quasar.stochastic.process.univariate.StochasticTrendModelBuilder')
        # final String name, final double[] data, final int cycleLength
        self._inner = builder.createFromData(name, df[name], cycle_length)

        if log_transform:
            self._inner = self._inner.logTransform()

        if bootstrap_errors is not None:
            self._inner = self._inner.bootstrapErrors(bootstrap_errors)

        if bandwidth is not None:
            self._inner = self._inner.bandwidth(bandwidth)

        if heavy_tailed:
            self._inner = self._inner.heavyTailed()

        if smoothing_method is not None:
            if smoothing_method == 'kernel_density':
                self._inner.smoothingMethod(True)
            elif smoothing_method == 'moving_average':
                self._inner.smoothingMethod(False)
            else:
                raise Exception('Unknown smoothing method.')

        self._inner = self._inner.build()

        if warm_up_phase is not None:
            self._inner = self._inner.warmUpPhase(warm_up_phase)

        if truncate:
            self._inner = self._inner.truncateZero()

        if initial_stage is not None:
            self._inner = self._inner.setInitialStage(initial_stage)

        # debug
        self.df = df

    @classmethod
    def from_data(cls,
                  name,
                  cycle_length,
                  source=None,
                  log_transform=False,
                  smoothing_method=None,
                  bootstrap_errors=None,
                  warm_up_phase=None,
                  heavy_tailed=False,
                  truncate=False,
                  bandwidth = None,
                  initial_stage = None,
                  initial_state = None,
                  csv_options={}):
        """Estimates the model for a given sample.

        Keyword Args:
            source (str or pandas.Dataframe, optional): Path to CSV or Pandas Dataframe.
            csv_options (dict, optional): If your CSV requires special attention, those parameters will be passed to
                pandas.read_csv().
            bootstrap_errors (int, optional):  Instead of sampling errors from a normal distribution,
                the simulation model will bootstrap from the empirical error distribution instead.
                In a periodic model, the distribution is likely to vary over time, so should the errors.
            smoothing_method (str, optional): Possible options: kernel_density, moving_average
            warm_up_phase (int, optional): Simulate the state transition process for a certain number of iterations
                before generating a new sample path.
            truncate (bool, optional): Truncated the process at zero in all dimensions. Recommended in case random variables
                must be positive.
            log_transform (bool, optional): Performs a log transformation before model estimation. Note that a log
                transformation will lead to a skewed error distribution, such that upward errors have a longer tail
                than downward errors and are strictly positive.
            bandwidth (int, optional): Define the width of the smoothing window for the long-term trend model.
            initial_stage (int, optional): Set the initial values of the AR model. If no initial values
                are provided, all initial (lagged) values are assumed to be zero. Use warm_up_phase
                to get a non-zero random initial state.
            initial_state (float, optional): Set the initial values of the AR model. If no initial values are
                provided, all initial (lagged) values are assumed to be zero. Use {@link #warmUpPhase(int)} to get a
                non-zero random initial state.


        Example:
            >>> inflowProcess = StochasticTrendModel.from_data(
                    'inflow', 365,
                    source='imports/inflows.csv',
                    smoothing_method='kernel_density',
                    log_transform=True,
                    truncate=True,
                    csv_options={'sep': ','}
                    )
        """
        warnings.warn("StochasticTrendModel is deprecated. Use Lattice.from_data or fit a StateSpaceModel.",
                      category=DeprecationWarning)
        my_process = cls.__new__(cls)
        my_process._load_data(my_process, source, csv_options, name, cycle_length, log_transform,
                              smoothing_method, warm_up_phase, truncate, bootstrap_errors, bandwidth,
                              heavy_tailed, initial_stage, initial_state)
        return my_process

UnivariateTrendModel = StochasticTrendModel