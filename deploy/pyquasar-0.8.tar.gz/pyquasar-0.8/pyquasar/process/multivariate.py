# -*- coding: utf-8 -*-

from bunch import Bunch
import jpype
import warnings

from . import MarkovProcess


class MGBM(MarkovProcess):
    """Multivariate geometric Brownian motion (GBM) in discrete time.

    Arguments:
        names (list of str): names of the state variables
        initial_state (list of float): Initial state  (do not log-transform)
        drift (list of float): drift parameters
        correlation (list of float): Correlation matrix

    Returns:
        MarkovProcess: An instance of MarkovProcess

    Example:
        >>> my_gbm = MultivariateGBM(
        >>>        names=["Demand0", "Demand1", "Demand2"],
        >>>        initial_state=[10, 10, 10],
        >>>        drift=[0, 0, 0],
        >>>        volatility=[0.2, 0.2, 0.2],
        >>>        correlation=[[1, 0.3, 0.7], [0.3, 1, 0], [0.7, 0, 1]])
    """
    def __init__(self, names, initial_values, drift, volatility, correlation):
        mgbm = jpype.JClass('com.quantego.quasar.stochastic.process.multivariate.MultivariateGBM')
        initial_values = [float(c) for c in initial_values]
        drift = [float(c) for c in drift]
        volatility = [float(c) for c in volatility]
        correlation = [[float(c) for c in d] for d in correlation]
        self._inner = mgbm.create(names, initial_values, drift, volatility, correlation)

MultivariateGBM = MGBM

class VARModel(MarkovProcess):
    """The vector autoregressive (VAR) model as a MarkovProcess.

    State variable realizations of a sample path can be accessed by
    the given name 'varname', while independent variables of higher-order lags
    (>2) can be accessed via 'varname:t'. Independent variables at higher order
    lags can therefore be used as model parameters.

    Without further information, the initial state of the process is assumed to be zero, which
    will likely induce an initialization bias. The class provides two means
    to avoid bias. Either, the user specifies a warm-up phase, or, the user
    provides a set of initial values.

    Arguments:
        names (list of str):  Vector of state variable names of length n
        mean (list of float):  Vector of constant terms of length n
        covariance (list of float): (n x n) covariance matrix
        coefficients (list of list(float)): VAR Coefficients as p (n x n) matrices, with p being the number of lags.

    Keyword Arguments:
        initial_state: (list of float, optional): Initial state of the VAR model as a matrix with the current state
            as the first row: [t,t-1,...,t-p]. The number of rows must equal the number of lags and the number of
            columns must equal the number of state variables.
       log_transform (list of bool, optional): Log-transform states before each transition to obtain a geometric process
       truncate (list of float, optional): Truncate all at [min,max]
       truncate_zero (bool, optional): Truncate all at zero
       warm_up_phase (int, optional):  Number of state transitions to overcome the initial transient phase.

    Returns:
        MarkovProcess: An instance of MarkovProcess

    Example:
        >>> VARModel(
        >>>     names = ['demand', 'price']
        >>>     constants = [4, 5],
        >>>     covariance = [[1, 0.5], [0.5,1]],
        >>>     coefficients = [[[0.7],[0.2]],[[0.2],[0.7]]],
        >>>     warm_up_phase = 50
        >>> )
    """

    def __init__(self, names, constants, covariance, coefficients,
                 initial_state=None,
                 log_transform=None,
                 truncate=None,
                 truncate_zero=False,
                 warm_up_phase=None):
        var_model = jpype.JClass('com.quantego.quasar.stochastic.process.multivariate.VARModel')
        means = [float(c) for c in constants]
        covariance = [[float(c) for c in d] for d in covariance]
        coefficients = [[[float(e) for e in c] for c in d] for d in coefficients]
        self._inner = var_model.create(names, means, covariance, coefficients)

        if initial_state:
            if len(initial_state) < len(coefficients):
                raise IndexError("Number of initial states must equal the number of lags.")
            for i in range(len(initial_state)):
                self._inner.initialState(i,[float(c) for c in initial_state[i]])
        if truncate:
            try:
                self._inner.truncate(float(truncate[0]), float(truncate[1]))
            except IndexError:
                raise IndexError("truncate has two arguments.")
            except:
                raise
        if truncate_zero:
            self._inner.truncateZero()
        if warm_up_phase:
            self._inner.warmUpPhase(int(warm_up_phase))
        if log_transform:
            self._inner.logTransform()

    def _init_from_df(self, df, periodic_bootstrap, seasonal_cycle,
                      dependency, truncate_zero, warm_up_phase, linear_trend,
                      bootstrap_errors, log_transform, set_all_lag_one, lag,
                      initial_state, initial_stage):
        """Initialize process using a DataFrame as input."""

        vmb = jpype.JClass('com.quantego.quasar.stochastic.process.multivariate.VARModelBuilder')
        self._inner = vmb.createFromData(list(df.columns), df.dropna().values)

        if periodic_bootstrap is not None:
            self._inner = self._inner.periodicBootstrap(periodic_bootstrap)

        if seasonal_cycle is not None:
            self._inner = self._inner.seasonalCycle(seasonal_cycle)

        if dependency:
            for d in dependency:
                self._inner = self._inner.setDependency(d[0], d[1], d[2])

        if linear_trend is not None:
            self._inner = self._inner.linearTrend(linear_trend)

        if bootstrap_errors:
            self._inner = self._inner.bootstrapErrors()

        if log_transform:
            self._inner = self._inner.logTransform(log_transform)

        if set_all_lag_one:
            self._inner = self._inner.setAllLagOne()

        if lag:
            for l in lag:
                self._inner = self._inner.setLag(l[0], l[1])

        self._inner = self._inner.build()

        if initial_state is not None:
            initial_state.reverse()
            for lag in range(len(initial_state)):
                self._inner = self._inner.initialState(lag, [float(s) for s in initial_state[lag]])

        if initial_stage is not None:
            self._inner = self._inner.setInitialStage(initial_stage)

        if warm_up_phase is not None:
            self._inner = self._inner.warmUpPhase(warm_up_phase)

        if truncate_zero:
            self._inner = self._inner.truncateZero()

        # debug
        self.df = df

    @classmethod
    def from_data(cls, source=None,
                  periodic_bootstrap=None,
                  seasonal_cycle=[1],
                  dependency=[],
                  truncate=False,
                  warm_up_phase=None,
                  linear_trend=None,
                  bootstrap_errors = False,
                  log_transform = None,
                  set_all_lag_one = False,
                  lag = [],
                  initial_stage = None,
                  initial_state = None,
                  csv_options={}):
        """Estimates a VARModel for a given sample.

        Keyword Args:
            source (str or pandas.Dataframe, optional): Path to CSV or Pandas Dataframe.
            csv_options (dict, optional): If your CSV requires special attention, those parameters will be passed to
                pandas.read_csv().
            periodic_bootstrap (int, optional): Instead of sampling errors from a normal distribution,
                the simulation model will bootstrap from the periodic empirical error distribution, whereby
                the process with the longest period is taken. Note that this requires a sufficient number
                of observations, e.g. if period is one year, at least 20 years of data.
            seasonal_cycle (list of int, optional): Define the seasonal cycle (period) of each dependent variable.
            dependencies (list of int or str): Define a known relationship between a variable and another
                lagged variable. Variable can be str or int index.
            warm_up_phase (int, optional): Simulate the state transition process for a certain number of iterations
                before generating a new sample path.
            linear_trend (list of int): Adds a linear trend to the regression equation which influences the
                level of the mean of the error distribution.
            truncate (bool): Truncated the process at zero in all dimensions. Recommended in case random variables
                must be positive.
            bootstrap_errors (bool, optional): Instead of sampling errors from a normal distribution, the simulation
                model will bootstrap from the empirical error distribution instead. Note that this requires errors
                to be at least identically distributed. If errors change periodically, use periodic_bootstrap instead.
            log_transform (list of int): Performs a log transformation before model estimation. Note that a log
                transformation will lead to a skewed error distribution, such that upward errors have a longer
                tail than downward errors and are strictly positive.
            set_all_lag_one (bool, optional): Define a known relationship between a variable and another lagged variable.
            lag (list of int): Convenience method if a purely autoregressive structure is needed for a given variable.
            initial_stage (int, optional): Set the initial values of the AR model. If no initial values
                are provided, all initial (lagged) values are assumed to be zero. Use warm_up_phase
                to get a non-zero random initial state.
            initial_state (list of float, optional): Set the initial values of the AR model. If no initial values are
                provided, all initial (lagged) values are assumed to be zero. Use {@link #warmUpPhase(int)} to get a
                non-zero random initial state.


        Example:
            >>> inflowProcess = VARProcess.from_data(
                periodic_bootrap=31,
                seasonal_cycle=[365],
                dependency=[[0, 0, [1, 2, 5]], ['price1', 'price5', [1, 2, 5]]]
                truncate=True,
                warm_up_phase = 365,
                linear_trend=[4, 3, 4],
                log_transform = [4, 6, 7]
                lag = [[4, 5], [6, 7]],
                initial_state = [
                    [solar,gas,...,preis1,...preis24] # lag 1
                    [solar,gas,...,preis1,...preis24] ], # lag 0
                csv_options={sep: ','}
            )
        """
        warnings.warn("Function from_data is deprecated. Use statsmodels.ts to fit a"
                      "VAR model.",category=DeprecationWarning)
        my_process = cls.__new__(cls)
        my_process._load_data(my_process, source, csv_options, periodic_bootstrap, seasonal_cycle,
                              dependency, truncate, warm_up_phase, linear_trend, bootstrap_errors,
                              log_transform, set_all_lag_one, lag, initial_state, initial_stage)
        return my_process

VARProcess = VARModel

class StateSpaceModel(MarkovProcess):
    """State space model as a Markov process.

    Arguments:
        names (list of str):  The variable names for further reference in the model.
        measurement_names (list of str): Measurements

    Keyword Arguments:
        number_stages,
        number_states,
        number_measurements,
        initial_state (list of float, optional): Initial states
        initial_measurement (list of float, optional): Initial measurments
        transition_matrix (list of float, optional): The transition matrix
        output_matrix (list of float, optional): Output matrix
        mean_1 (list of float, optional): Mean
        covariance_1 (list of float, optional): Cov
        mean_2 (list of float, optional): Mean
        covariance_2(list of float, optional): Cov
        log_transform_all (bool, optional):
        truncate (bool, optional): Truncate negative values.
        warm_up (int, optional): Number of warm-up phases.
        stationary (bool, optional): Create stationary state space model (Default = False)

    Returns:
        MarkovProcess: An instance of MarkovProcess

    """

    def __init__(self,
                 state_names,
                 measurement_names,
                 log_transform = True,
                 stationary = False,
                 **kwargs
    ):
        j = jpype.JClass('com.quantego.quasar.stochastic.process.multivariate.StateSpaceModel')

        if 'covariance_2' not in kwargs:
            kwargs['covariance_2'] = None
        else:
            kwargs['covariance_2'] = [[[float(c) for c in d] for d in a] for a in kwargs['covariance_2'] ],

        k = Bunch(kwargs)

        if stationary:
            # String[] stateNames, String[] measurementNames, double[] initialState, double[] initialMeasurement, double[][] transitionMatrix, double[][] outputMatrix, double[] mean1, double[][] covariance1, double[] mean2, double[][] covariance2
            self._inner = j.createStationary(
                state_names,
                measurement_names,
                k.initial_state,
                k.initial_measurement,
                k.transition_matrix,
                k.output_matrix,
                k.mean_1,
                k.covariance_1,
                k.mean_2,
                k.covariance_2)
        else:
            #(int numStages, int numStates, int numMeasurements, String[] stateNames, String[] measurementNames,  double[] initialState, double[] initialMeasurement,
            # double[][][] transitionMatrix, double[][][] outputMatrix, double[][] mean1, double[][][] covariance1,
            # double[][] mean2, double[][][] covariance2
            self._inner = j.createNonstationary(
                k.number_stages,
                k.number_states,
                k.number_measurements,
                state_names,
                measurement_names,
                [float(c) for c in k.initial_state],
                [float(c) for c in k.initial_measurement],
                [[[float(c) for c in d] for d in a] for a in k.transition_matrix ],
                [[[float(c) for c in d] for d in a] for a in k.output_matrix ],
                [[float(c) for c in d] for d in k.mean_1] ,
                [[[float(c) for c in d] for d in a] for a in k.covariance_1 ],
                [[float(c) for c in d] for d in k.mean_2],
                k.covariance_2
            )

        if log_transform:
            self._inner = self._inner.logtransformAll()