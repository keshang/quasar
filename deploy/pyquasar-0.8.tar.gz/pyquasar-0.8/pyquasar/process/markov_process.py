import os
from IPython.core.display import display
import jpype
import numpy as np
try:
    from StringIO import StringIO
except ImportError:
    from io import StringIO
import pandas as pd
from contracts import contract
from ..quasar_dataframe import QuasarDataFrame
import warnings


class MarkovProcess(object):
    """
    Superclass for all stochastic processes. Implements common functionality for sampling and simulating a process.
    """
    _inner = None

    def __init__(self):
        pass

    def __add__(self, other):
        if isinstance(other, MarkovProcess):
            return CombinedProcess(self, other)

    def _init_from_df(self, *args):
        pass

    @classmethod
    @contract(df=QuasarDataFrame)
    def from_df(cls, df):
        """
        Create a markov process from a Quasar DataFrame.

        Arguments:
            df(QuasarDataFrame): The QuasarDataFrame to turn into a MarkovProcess.

        Example:
            >>> proc = MarkovProcess.from_df(sim.state)
        """

        assert not isinstance(df.columns, pd.core.index.MultiIndex), 'Please only pass a DF with a single level, e.g. sim.state'

        keys = df.columns
        series = max(df.index.get_level_values(0)) #simulations

        # series > vars/keys > stage
        out = []
        for i in range(series):
            out.append(df.query('series == %i'%i).values)

        ts = jpype.JClass('com.quantego.quasar.stochastic.process.TimeSeriesSample')
        ts = ts.createFromKeyValueSample(out, keys)
        ts_ret = cls()
        ts_ret._inner = ts
        return ts_ret


    @staticmethod
    def _load_data(my_process, source, csv_options, *args):
        """Accept CSV or DF as input, read data and initialize child class with right args."""

        # Load CSV via File Upload Widget.
        if source is None:
            from ..utils.file_upload import FileWidget
            file_widget = FileWidget()

            def file_failed():
                print("Could not load file contents of %s" % file_widget.filename)
            file_widget.errors.register_callback(file_failed)

            def file_loaded():
                df = pd.read_csv(StringIO.StringIO(
                    file_widget.value), **csv_options)
                print("Done loading contents from %s" % file_widget.filename)
                my_process._init_from_df(df, *args)
            file_widget.on_trait_change(file_loaded, 'value')

            display(file_widget)

        # Load from db via DataFrame
        elif isinstance(source, pd.DataFrame):
            my_process._init_from_df(source, *args)
            print('Done loading process from DataFrame.')

        # Load from CSV file
        elif os.path.isfile(source):
            df = pd.read_csv(source, **csv_options)
            my_process._init_from_df(df, *args)
            print('Done loading process from %s' % source)

        else:
            raise Exception("Input source is not a DataFrame or file.")

    def simulate(self, num_stages, sample_size=100):
        """Create a DataFrame from simulating the given MarkovProcess.

        Arguments:
            num_stages(int) -- number of stages for each sample path

        Keyword Args:
            sample_size (int) -- sample size (number of simulated time series). (Default=100)

        Returns:
            QuasarDataFrame: data frame that holds a sample of time series
        """
        ts_sample = jpype.JClass('com.quantego.quasar.stochastic.process.TimeSeriesSample')
        ts_sample = ts_sample.createSampleFromSimulation(self._inner, int(num_stages), int(sample_size))
        return QuasarDataFrame._from_time_series_sample(ts_sample)

    def sample(self, num_stages, sample_size=100):
        warnings.warn("Function sample is deprecated. Use simulate instead.", category=DeprecationWarning)
        return self.simulate(num_stages, sample_size)

class AggregatedProcess(MarkovProcess):
    """Aggregates states across multiple periods into a single state.

    Args:
        process (MarkovProcess): an implementation of MarkovProcess.
        periods_per_stage (int or list of int): number of periods that are being aggregated into one stage

    Example:
        >>> uni_gbm = UnivariateGBM("price", initial_price, drift, volatility)
        >>> AggregatedProcess(uni_gbm, 15)
        >>> AggregatedProcess(uni_gbm, [15, 12])
    """
    def __init__(self, process, periods_per_stage):
        if not isinstance(process,MarkovProcess):
            raise TypeError('Type %s. Allowed type(s) for num_vars: MarkovProcess.'%type(process))
        agg = jpype.JClass('com.quantego.quasar.stochastic.process.AggregatedProcess')
        if type(periods_per_stage) == list and type(periods_per_stage[0]) == int:
            self._inner = agg.createVariableLength(process._inner, periods_per_stage)
        elif type(periods_per_stage) == int:
            self._inner = agg.createFixedLength(process._inner, periods_per_stage)
        else:
            raise Exception('periods_per_stage should be int or list of int')

class CombinedProcess(MarkovProcess):
    """Create a combination of several Markov processes.

    Variables can be accessed in the same way as with the individual processes. If two processes have the same
    variables names an exception is thrown. The user thus has to make sure that state variable names do not overlap.

    Consider using a CombinedProcess when two processes are statistically independent like wind speed and electricity
    demand.

    Tip: Use the '+' operator to combine two processes. If more than two processes are supposed to be combined, using
    the constructor and passing the processes as arguments is more efficient.

    Example:
        >>> d1 = ARModel("Demand1", 25, 5, [0.5])
        >>> d2 = ARMAModel("Demand2", 50, 10, [0.8], [0.1,0.3])

        >>> combined_demand = d1 + d2
    """
    def __init__(self, *processes):
        processes_ = []
        for p in processes:
            if not isinstance(p,MarkovProcess):
                raise TypeError('Type %s. Allowed type(s) for num_vars: MarkovProcess.'%type(p))
            processes_.append(p._inner)
        combined = jpype.JClass('com.quantego.quasar.stochastic.process.CombinedProcess')
        self._inner = combined(processes_)