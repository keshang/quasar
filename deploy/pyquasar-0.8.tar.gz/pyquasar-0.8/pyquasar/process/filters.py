import jpype
import json
import pandas as pd
from sklearn.utils.validation import check_array, as_float_array

from pyquasar.pyquasar_config import VALID_NUMERICS

class TimeSeriesSmoothing():
    """Extract the trend component of a time series using local linear regression with a step function as kernel.

    Arguments:
        data (list(float)) -- time series data

    Keyword arguments:
        bandwidth (int) -- bandwidth of the local regression (Default = 2/3*len(data))
    """

    def __init__(self, data, bandwidth=None):
        builder = jpype.JClass('com.quantego.quasar.stochastic.process.TimeSeriesSmoothing')
        data = check_array(data)
        data = as_float_array(data, copy=False)
        builder = builder.create(data[0].tolist())
        if bandwidth:
            builder.bandwidth(int(bandwidth))
        result = builder.fit()
        self._inner = result

    def trend(self):
        """Return the trend component.
        """
        return list(self._inner.getTrend())

    def errors(self):
        """Return the errors (residuals).
        """
        return list(self._inner.getErrors())

class TimeSeriesRegression():
    """TimeSeriesRegression extracts trend and seasonal components from a univariate time series.

    The class uses a linear regression model to estimate seasonal, trend and other components from thea time series.
    The implemented model and methods offer the following features:

    - A Fourier decomposition with multiple cycles where the frequencies are selected automatically using AIC or BIC.
    - A local trend component based on a piecewise linear trend model with breakpoints in regular intervals.
    - An explanatory component to include holiday dummies and time series of deterministic explanatory variables.

    For very long time series with many seasons, it is recommended to use a local trend with a period that corresponds
    to the cycle length of the seasonal component. In particular when the level of the trend is changing over time.

    Arguments:
        data (list(float)) -- time series data

    Keyword arguments:
        include_trend (bool, optional) -- Include a trend component in the regression model. (Default: False)
        local_trend (int, optional) -- Include a trend component that is defined by a local trend that changes every
            k periods. The trend component is modeled by a piecewise linear trend with equidistant breakpoints.
            This allows to fit trend all components in one shot. (Default: None)
        seasonal_cycle(float or list(float), optional) -- Define one or more seasonal cycles with a given period. (Default: None)
        model_selection(str, optional) -- Use the AIC or BIC for automatic model selection. (Default: 'AIC')
        explanatory_values(list(float), optional) -- Add other explanatory variables as predictors,
            for example holiday dummies. The size of the array must correspond to the length of the time series sample.
            (Default = None).
        explanatory_names(list(float), optional) -- Names of explanatory variables. (Default = None).

    Attributes:
        df (int) -- the degrees of freedom
        aic (float) -- the Akaike information criterion (AIC)
        bic (float) -- the Bayesian information criterion (BIC)
        final_trend (float) -- the level of the trend at the final observation
        rsquared (float) -- the coefficient of determination (R-squared)
        sse (float) -- the residual sum of squares

    Example:
        >>> regression = TimeSeriesRegression(data, seasonal_cycle=365)
        >>> trend = regression.trend()
        >>> season = regression.season()
    """

    _inner = None

    def __init__(self, data,
                 include_trend=False,
                 local_trend=None,
                 seasonal_cycle=None,
                 model_selection='AIC',
                 explanatory_values=None,
                 explanatory_names=None):

        builder = jpype.JClass('com.quantego.quasar.stochastic.process.TimeSeriesRegression')
        data = check_array(data)
        data = as_float_array(data, copy=False)
        builder = builder.create(data[0].tolist())
        if include_trend:
            builder.includeTrend()
        if local_trend is not None:
            if type(local_trend) is int:
                builder.localTrend(local_trend)
            else:
                raise TypeError('Type %s. Allowed type(s) for local_trend: int.'%type(local_trend))
        if seasonal_cycle is not None:
            if isinstance(seasonal_cycle, VALID_NUMERICS):
                builder.seasonalCycles([float(seasonal_cycle)])
            elif isinstance(seasonal_cycle, (list, tuple)) and isinstance(seasonal_cycle[0], VALID_NUMERICS):
                builder.seasonalCycles([float(i) for i in seasonal_cycle])
            else:
                raise TypeError('Type %s. Allowed type(s) for local_trend: int, list(int).'%type(seasonal_cycle))
        else:
            builder.fourierOff()
        if model_selection == 'AIC':
            builder.aic()
        elif model_selection == 'BIC':
            builder.bic()
        else:
            raise KeyError('Option %s. Allowed options for model_selection: AIC, BIC.'%model_selection)
        if explanatory_values is not None:
            explanatory_values = check_array(explanatory_values)
            explanatory_values = as_float_array(explanatory_values, copy=False)
            if explanatory_names is None:
                    builder.explanatory(explanatory_values)
            else:
                if type(explanatory_names) is list and type(explanatory_names[0]) is str:
                    builder.explanatory(explanatory_values, explanatory_names)
                else:
                    raise TypeError('Type %s. Allowed type(s) for explanatory_names: list(str).'%type(explanatory_names))
        result = builder.fit()
        self._inner = result
        self.df = result.getDF()
        self.aic = result.getAIC()
        self.bic = result.getBIC()
        self.final_trend = result.getFinalLevel()
        self.r2 = result.getR2()
        self.mse = result.getMSE()
        self.sse = result.getSSE()

    def trend(self):
        """Return the trend component.
        """
        return list(self._inner.getTrend())

    def season(self):
        """Return the seasonal component.
        """
        return list(self._inner.getSeason())

    def errors(self):
        """Return the errors (residuals).
        """
        return list(self._inner.getErrors())

    def explanatory(self):
        """Return the explanatory component (if available).
        """
        return list(self._inner.getExogenous())

    def predict(self, num_stages, explanatory=None):
        """Compute a forecast beginning with the final trend level plus the seasonal component.

        If explanatory variables were used to fit a model, these must be provided for the prediction
        as well. Otherwise an exception will be thrown.

        Arguments:
            num_stages (int) -- number of stages to predict into the future
            explanatory (list(list((float))) -- explanatory variables as a nested list of floats
        """
        if type(num_stages) is not int:
            raise TypeError('Type %s. Allowed type(s) for num_stages: in.'%type(num_stages))
        if explanatory is None:
            return self._inner.getForecast(num_stages)
        else:
            explanatory = check_array(explanatory)
            explanatory = as_float_array(explanatory, copy=False)
            if len(explanatory) == num_stages:
                return self._inner.getForecast(num_stages, explanatory)
            else:
                raise IndexError('List explanatory must be of length num_stages')

    def summary(self):
        """Get a summary of the model results
        """

        def json_to_summary_df(js):
            parameters_labels = ['parameters' for i in js['parameters']]
            stdErrors_labels = ['stdErrors' for i in js['stdErrors']]
            single_labels = ['AIC', 'BIC', 'MSE', 'R2', 'SSE', 'df']
            index_outer = single_labels + parameters_labels + stdErrors_labels
            index_inner = single_labels + list(js['parameters'].keys()) + list(js['stdErrors'].keys())
            values_single = [js[k] for k in single_labels]
            values_parameters = [js['parameters'][k] for k in js['parameters'].keys()]
            values_stdErrors = [js['stdErrors'][k] for k in js['stdErrors'].keys()]

            data = values_single + values_parameters + values_stdErrors
            return pd.DataFrame(data, index=[index_outer, index_inner], columns=['Value'])

        json_str = self._inner.getSummary()
        js = json.loads(json_str)
        return json_to_summary_df(js)

