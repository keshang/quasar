"Base test to provide common starting point to other test. E.g. model formulation."


# TODO: avoid duplicate code in tests.
class BaseTest(object):
    def setUp(self):
        model = DecisionProblem('Production').maximize()
        process = ARModel('Demand', 25, 5, [0.5], truncate_zero=True) #ARModel("Demand", 25, 5, [0.5])

        oldInventory = 20

        for t in range(6):
            produce, inventory, sell = model.add_variables(t, num_vars=3)

            #objective function
            #print(5*sell - 3*produce - 0.5*inventory)
            model += 5*sell - 0.5*inventory - 3*produce

            #inventory balance
            model += inventory == oldInventory - sell + produce

            #bounds
            model += sell <= rand('Demand')
            model += sell <= inventory
            model += produce <= 50
            oldInventory = inventory

        self.model = model
        self.process = process
