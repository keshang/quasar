import pyquasar
import unittest

def run(verbosity=1):
    tests = unittest.TestLoader().discover(pyquasar.__path__[0])
    result = unittest.TextTestRunner(verbosity=verbosity).run(tests)
    result.printErrors()
    print('Passed:', result.wasSuccessful())