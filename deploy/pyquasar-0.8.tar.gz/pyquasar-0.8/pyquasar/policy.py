from .solution import Solution
from .quasar_dataframe import QuasarDataFrame
import jpype

class Policy:
    """A Policy is a solution to a stochastic-dynamic decision problem.

    The DynamicOptimizer and the StaticOptimizer return a Policy upon calling the solve method.

    A Policy can be simulated which returns realizations of decisions, states, etc. A Policy also provides a solution
    for a given state. Since the first stage is often deterministic, the solution to the first-stage problem can
    be obtained by calling the respective function.
    """
    def __init__(self, java_policy):
        self._inner = java_policy

    def first_stage_solution(self):
        """Return the first-stage solution."""
        return Solution(self._inner.getFirstStageSolution())

    def simulate(self,
                 sample_size=100,
                 num_stages=None,
                 process=None,
                 synthetic_value_function=0,
                 nearest_problem=False,
                 num_threads=None):
        """Apply the policy to solve the optimization problem for a number of forward
        simulations of the Markov process.

        Keyword arguments:
            sample_size (int): Number of simulations to run.
            num_stages (int): Number of stages used in simulation. Must be less or equal to the number of
              stages used during optimization. Default: number of stages used during optimization.
            process: MarkovProcess to use for simulation.
            synthetic_value_function (int): Construct a value function for the current state of the process
              on-the-fly using a sample of state transitions of given size to estimate the transition probabilities
            nearest_problem (boolean): Instead of rounding to the nearest value function, round to the nearest
              problem. This only works as designed with randomness in the objective function.

        Returns:
            QuasarDataFrame: Simulation results

        Example:
            >>> df = opt.simulate(sample_size=1000)
        """
        if num_stages is None:
            num_stages = self._inner.getNumStages()
        else:
            assert num_stages <= self._inner.getNumStages(), \
                'num_stages must be less or equal to the number of stages used during optimization.'

        if num_threads:
            self._inner.numberOfThreads(int(num_threads))

        if synthetic_value_function > 0 :
            self._inner = self._inner.syntheticValueFunction(int(synthetic_value_function))

        if nearest_problem:
            self._inner = self._inner.nearestProblemRounding()

        if process is not None:
            self._inner = self._inner.markovProcess(process._inner)

        # try:
        simulation_res = self._inner.simulate(sample_size, num_stages)
        return QuasarDataFrame._from_simulation(simulation_res)
        # except (jpype.JException(jpype.java.lang.IllegalStateException),
        #         jpype.JavaException), exception:
        #     print(exception.stacktrace())


