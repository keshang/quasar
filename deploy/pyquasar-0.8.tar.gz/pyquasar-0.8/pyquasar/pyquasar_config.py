from __future__ import print_function
from bunch import Bunch
import pkg_resources
import matplotlib.pyplot as plt
import os
import numpy as np


# Set options and collect in Dict file.
c = Bunch() # TODO: move to a proper config file format? .ini?

c.PLOT_SIZE = (8, 4)  # (width, height) in inches
c.OPTIMIZER_DEFAULT_SCENARIOS = 50

c.OPTIMIZER_DEFAULT_SIMULATIONS = 100
c.OPTIMIZER_DEFAULT_MIN_SIMULATIONS = 10
c.OPTIMIZER_DEFAULT_MAX_SIMULATIONS = 1000

c.OPTIMIZER_INITIAL_ITERATIONS = 5
c.OPTIMIZER_WIDGET_ITERATIONS_MIN = 5
c.OPTIMIZER_WIDGET_ITERATIONS_DEFAULT = 20
c.OPTIMIZER_WIDGET_ITERATIONS_MAX = 500

c.OPTIMIZER_WIDGET_AUTO_DEFAULT = False

c.FANCHART_LOWER = 0.25
c.FANCHART_UPPER = 0.75

#c.DEFAULT_SOLVER = 'SULUM'
VALID_NUMERICS = (int, float, np.integer, np.floating)

c.STYLESHEET = 'quantego' # searches in /assets/mplstyl.

# Apply some options on import
plt.style.use(pkg_resources.resource_filename(__name__, 'assets/mplstyle/{}.mplstyle'.format(c.STYLESHEET)))
