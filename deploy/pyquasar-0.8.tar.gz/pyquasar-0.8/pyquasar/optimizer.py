# -*- coding: utf-8 -*-
from __future__ import print_function
import json
import jpype
from IPython.display import clear_output
from IPython.utils.warn import warn
from matplotlib import pyplot as plt
import numpy as np
from bunch import Bunch
from datetime import datetime as dt, timedelta
import pandas as pd
from mpltools import special
import threading

from .pyquasar_config import c as config
from .process import MarkovProcess
from .policy import Policy
from .lattice import Lattice
from .model import DecisionProblem
from .quasar_dataframe import QuasarDataFrame


class StaticOptimizer(object):
    """StaticOptimizer solves a DecisionProblem that has random parameters defined through a MarkovProcess.

    The StaticOptimizer offers a simple yet straightforward solution strategy to any stochastic optimization problem,
    which is often seen in practice, and as such offers a convenient benchmark. The idea is to ignore the stochastic
    part of the optimization completely and solve the dynamic part of the optimization problem by merely using the
    expectation of the stochastic process.

    The Policy provided by the StaticOptimizer is a lookahead policy which simulates the solution of a deterministic
    optimization over a rolling horizon, where future states of the stochastic process are replaced with their means.
    As new states are sampled, these expectations can be automatically updated over time.

    It is recommended to use this class before solving a stochastic optimization problem to assess the added value
    of a stochastic solution. In this regard, he functions get_clairvoyant() provides an upper bound, whereas
    get_policy().simulate() provides a lower bound to the stochastic optimization problem.

    Arguments:
        decision_problem (DecisionProblem): the model formulation
        markov_process (MarkovProcess, Lattice): the exogenous random process

    Keyword Arguments:
        linear_solver (str, optional): Pick linear solver to use. Currently supports sulum and clp. (Default = sulum)
        linear_solver_license (str, optional): Linear solver license string to use.
        num_threads (int, optional): Number of threads for optimization. Defaults to number of CPU cores.
        seed (long, optional): Random seed used for Monte Carlo sampling. The number of threads should be set equal to
            one to ensure that the solver result is reproducible. (Default = None)
        update_expectations (bool, optional):  Decide whether the lookahead policy updates its expectations about
            future states or whether these are kept fixed from the beginning. (Default = True)

    Attributes:
        policy (pyquasar.Policy): Policy derived from the StaticOptimizer.

    Examples:
        >>> opt = StaticOptimizer(my_problem, my_process)
        >>> opt.get_clairvoyant(samples=100)
    """

    def __init__(self, decision_problem, markov_process, **kwargs):
        super(self.__class__, self).__init__()

        #check if the provided input arguments are valid
        if not isinstance(decision_problem, DecisionProblem):
            raise Exception("Type %s. The problem is not of type DecisionProblem."%type(decision_problem))
        if not isinstance(markov_process, MarkovProcess):
            raise Exception("Type %s. The process is not of type MarkovProcess."%type(markov_process))

        #check if all the keyword args are valid
        known_keys = {'linear_solver', 'linear_solver_license',
                      'num_threads', 'seed', 'update_expectations'}
        #TODO: move this into a separate utility class
        Lattice._check_kwargs(known_keys, kwargs)
        kwargs = Bunch(kwargs)

        # TODO set default solver in java
        #kwargs['linear_solver'] = 'SULUM'

        # call the java builder
        builder = jpype.JClass('com.quantego.quasar.optimizer.StaticOptimizerBuilder')
        builder = builder.create(decision_problem._inner, markov_process._inner)
        if 'num_threads' in kwargs:
            builder.numberOfThreads(int(kwargs.num_threads))
        if 'update_expectations' in kwargs:
            builder.updateExpectations(bool(kwargs.update_expectations))
        if 'seed' in kwargs:
            generator = jpype.JClass("java.util.Random")
            builder.generator(generator(long(kwargs.seed)))
        if 'linear_solver' in kwargs:
            LINEARSOLVER = jpype.JClass("com.quantego.quasar.optimizer.LINEARSOLVER")
            builder.linearSolver(eval('LINEARSOLVER.' + kwargs['linear_solver']))
        # if 'linear_solver_license' in kwargs:
        #     builder.linearSolver(SOLVER, str(kwargs.linear_solver_license))
        # else:
        #     #TODO: do we have to catch a java exception here?
        #     builder.linearSolver(SOLVER, config.LICENSE)
        self._inner = builder.build()


    def get_clairvoyant(self, sample_size=100):
        """Returns the solution of the decision problem under perfect foresight, also known as the wait-and-see
        or clairvoyant solution.

        Keyword Args:
            samples (int): Sample size. (Default = 100)

        Example:
            >>> opt.simulate_clairvoyant(500)
        """
        sim = self._inner.getClairvoyantSolution(int(sample_size))
        return QuasarDataFrame._from_simulation(sim)


    def get_expected_value(self):
        """Returns the objective value of the problem with all random variables fixed to their expected values.
         This provides a naive estimate of the optimal expected value.

        Example:
            >>> opt.simulate_expected_value()
        """
        sim = self._inner.getExpectedValueSolution()
        return QuasarDataFrame._from_simulation(sim)

    @property
    def policy(self):
        """Return the look-ahead policy.
        """
        return Policy(self._inner.getPolicy())



class DynamicOptimizer(object):
    """DynamicOptimizer solves a DecisionProblem that has random parameters defined through a MarkovProcess.

    The DynamicOptimizer is capable of finding an optimal solution to a DecisionProblem where the MarkovProcess is
    defined through a Lattice. If the MarkovProcess is continuous it can be reduced to a Lattice that best represents the
    MarkovProcess. The optimal solution takes the form of a Policy that holds a solution for each stage of the
    DecisionProblem given a state of the MarkovProcess and the history of previous decisions.

    The DynamicOptimizer implements approximate dual dynamic programming, first introduced in
    Löhndorf, Wozabal, Minner (Operations Research, 2013), although the latest generation of the algorithm is much
    more efficient. The algorithm combines dual decomposition techniques for
    linear programming problems with learning techniques from approximate dynamic programming.

    Arguments:
        decision_problem (DecisionProblem): the model formulation
        markov_process (MarkovProcess, Lattice): the exogenous random process

    Keyword Arguments:
        absolute_gap (float): Sets the absolute gap between the expected reward and the
            simulated reward. (Default = 0.0)
        accuracy (float): Sets the accuracy of the convergence check. The accuracy is defined as the
            ratio of the half width of the 95% confidence interval and the sample mean. (Default = 0.05)
        aggressive_cut_removal (bool): Hyperplanes that have a tangential point that lies above a newly added
            hyperplane can be removed during the backward pass. (Default = false)
        confidence_interval (float): Sets the confidence level of the confidence interval for the convergence check.
            (Default = 0.95)
        discount_factor (float): Sets the factor that is used to discount rewards at future stages. (Default = 1.0)
        identical_subproblems (bool): Use this option if subproblems at intermediate stages are identical. This can
            significantlty decrease memory consumption for problems with many stages.
        linear_solver (str: Pick linear solver to use. Options: 'CLP', 'GLOP', and 'SULUM' (default).
        max_iterations (int): Stop solver after running for a maximum of X iterations. (Default = None)
        min_iterations (int): Run solver for at least X iterations. (Default = None)
        max_sample_size (int): Sets the maximum number of additional iterations if the algorithm has not converged.
            (Default = 10000)
        min_sample_size (int): Sets the minimum number of additional iterations if the algorithm has not
            converged. (Default = 100)
        nested_cvar ([alpha (float), lambda (float), num_iter (int)], optional) Assumes that expected profits are
            risk-adjusted by a nested CVaR formulation, which will produce a risk-averse policy. Since the expected value
            (upper bound) does not reproduce the expected reward from following the risk-averse policy, the user must
            provide the number of iterations. (Default = None)
            * alpha expected shortfall quantile
            * lambda percentage weight of the CVaR in the nested formulation
            * num_iter number of iterations of the dual dynamic optimizer
        num_nodes (int): Number of nodes used for scenario reduction if a MarkovProcess is provided.
        num_threads (int): Number of threads for optimization. Defaults to number of CPU cores.
        probability_updated (float): Sets the average cumulated unconditional probability of nodes updated during
            the backward pass. (Default = 1)
        relative_gap (float, optional): Sets the relative gap between the expected reward and the simulated
            reward. (Default = 0.005)
        remove_redundant_hyperplanes (bool): Hyperplanes that have a tangential point that lies above a newly
            added hyperplane can be removed during the backward pass. (Default = true)
        sampling_strategy (str): Set the sampling strategy which is used by the dual dynamic
            programming solver during the forward pass. Options: 'MARKOVIAN' (default), 'BAYESIAN'.
        seed (long): Random seed used for Monte Carlo sampling. The number of threads should be set equal to
            one to ensure that the solver result is reproducible. (Default = None)
        time_limit (float): Sets a time limit for the dynamic optimizer in seconds. The optimizer will
            stop after a backward pass if the time limit exceeds the given value. It will not interrupt the backward
            pass. (Default = None)
        window_size (int): Sets the size of the window which is used to asses whether a convergence
            check should be made. (Default = 20)

    Attributes:
        stats: Optimization statistics of each iteration as DataFrame
        plot: Convergence plot of the last simulation run.
        policy (pyquasar.Policy): Policy derived from the DynamicOptimizer.

    Example:
        >>> opt = DynamicOptimizer(my_problem, my_process)
        >>> opt = DynamicOptimizer(my_problem, my_process, nested_var=[.05, .1, 100]) # solve with a risk measure
    """

    def __init__(self, decision_problem, markov_process, **kwargs):
        super(self.__class__, self).__init__()

        #check if the provided input arguments are valid
        if type(decision_problem) is not DecisionProblem:
            raise Exception("Type %s. The problem is not of type DecisionProblem."%type(decision_problem))
        if not isinstance(markov_process, MarkovProcess):
            raise Exception("Type %s. The process is not of type MarkovProcess."%type(markov_process))

        #check if all the keyword args are valid
        known_keys = {'absolute_gap', 'accuracy', 'aggressive_cut_removal', 'confidence_interval','forward_sampling',
                      'probability_updated', 'max_sample_size',
                      'min_sample_size', 'num_threads', 'relative_gap', 'remove_redundant_hyperplanes', 'window_size',
                      'num_nodes', 'nested_cvar', 'terminal_cvar', 'sampling_strategy', 'linear_solver', 'linear_solver_license',
                      'min_iterations', 'max_iterations', 'time_limit', 'seed', 'discount_factor', 'identical_subproblems'}
        #TODO: move this into a separate utility class
        Lattice._check_kwargs(known_keys, kwargs)
        kwargs = Bunch(kwargs)

        # call the java builder
        builder = jpype.JClass('com.quantego.quasar.optimizer.DynamicOptimizerBuilder')
        # did we get a lattice or process?
        if type(markov_process) is Lattice:
            builder = builder.createFromLattice(decision_problem._inner, markov_process._inner)
        else:
            if 'num_nodes' in kwargs:
                num_nodes = int(kwargs.num_nodes)
            else:
                num_nodes = int(config.OPTIMIZER_DEFAULT_SCENARIOS)
                warn('Keyword num_nodes missing. The number of nodes per stage will '
                     'be automatically set to %d.' % num_nodes)
            builder = builder.create(decision_problem._inner, markov_process._inner, num_nodes)
        if 'absolute_gap' in kwargs:
            builder.absoluteGap(float(kwargs.absolute_gap))
        if 'accuracy' in kwargs:
            builder.accuracy(float(kwargs.accuracy))
        if 'aggressive_cut_removal' in kwargs:
            builder.aggressiveCutRemoval(bool(kwargs.aggressive_cut_removal))
        if 'confidence_interval' in kwargs:
            builder.confidenceInterval(float(kwargs.confidence_interval))
        if 'probability_updated' in kwargs:
            builder.probababilityUpdated(float(kwargs.probability_updated))
        if 'max_sample_size' in kwargs:
            builder.maxSampleSize(int(kwargs.max_sample_size))
        if 'min_sample_size' in kwargs:
            builder.minSampleSize(int(kwargs.min_sample_size))
        if 'num_threads' in kwargs:
            builder.numberOfThreads(int(kwargs.num_threads))
        if 'forward_sampling' in kwargs:
            process = kwargs.forward_sampling
            if isinstance(process, MarkovProcess):
                builder.forwardSampling(process._inner)
            else:
                raise TypeError('Type %s. Allowed type(s) for forward_sampling: MarkovProcess.'%type(process))
        if 'min_iterations' in kwargs:
            builder.minIterations(int(kwargs.min_iterations))
        if 'max_iterations' in kwargs:
            builder.maxIterations(int(kwargs.max_iterations))
        if 'time_limit' in kwargs:
            builder.timeLimit(float(kwargs.time_limit))
        if 'seed' in kwargs:
            generator = jpype.JClass("java.util.Random")
            builder.generator(generator(long(kwargs.seed)))
        if 'relative_gap' in kwargs:
            builder.relativeGap(float(kwargs.relative_gap))
        if 'remove_redundant_hyperplanes' in kwargs:
            builder.removeRedundantHyperplanes(bool(kwargs.remove_redundant_hyperplanes))
        if 'window_size' in kwargs:
            builder.windowSize(int(kwargs.window_size))
        if 'nested_cvar' in kwargs:
            param = kwargs.nested_cvar
            try:
                builder.nestedCVaR(float(param[0]), float(param[1]), int(param[2]))
            except IndexError:
                raise IndexError("nested_cvar has three arguments.")
            except:
                raise
        if 'discount_factor' in kwargs:
            builder.discountFactor(float(kwargs.discount_factor))
        if 'identical_subproblems' in kwargs:
            builder.identicalSubProblems(bool(kwargs.identical_subproblems))
        #if 'terminal_cvar' in kwargs:
        #    param = kwargs.terminal_cvar
        #    try:
        #        builder.terminalCVaR(float(param[0]), float(param[1]), float(param[2]), float(param[3]))
        #    except IndexError:
        #        raise IndexError("terminal_cvar has four arguments.")
        #    except:
        #        raise
        if 'sampling_strategy' in kwargs:
            FORWARDPASS = jpype.JClass("com.quantego.quasar.optimizer.FORWARDPASS")
            builder.samplingStrategy(eval('FORWARDPASS.' + kwargs['sampling_strategy']))

        LINEARSOLVER = jpype.JClass("com.quantego.quasar.optimizer.LINEARSOLVER")
        if 'linear_solver' in kwargs:
            builder.linearSolver(eval('LINEARSOLVER.' + kwargs['linear_solver']))
        else:
            builder.linearSolver(eval('LINEARSOLVER.SULUM'))

        builder.exitOnEnter(False)
        self._inner = builder.build()
        self._stats = []
        self._stop_solver = False
        self._num_iter = 0
        self._iterations = None
        self._min_iterations = None
        self._max_iterations = None
        self._time_limit = None

    def run(self):
        jpype.attachThreadToJVM()
        if self._iterations is not None and self._iterations > 0:
            self._solve_iterate()
        else:
            self._solve_batch()

    def stop(self):
        """Stop the solution thread.
        """
        self._stop_solver = True

    def _solve_batch(self):
        """Run at least min_iterations but at most max_iterations and stop upon convergence."""
        start_time = dt.utcnow()

        # Add duration of previous runs, so we have total running time over multiple runs.
        if self._stats:
            previous_duration = self._stats[len(self._stats)-1]['duration']
        else:
            previous_duration = 0

        if self._time_limit:
            end_time = start_time + timedelta(seconds=self._time_limit)
        else:
            end_time = float('inf')
        if not self._max_iterations:
            self._max_iterations = float('inf')
        self._stop_solver = False
        self._num_iter = 0
        while end_time > dt.utcnow() and self._num_iter < self._max_iterations and not self._stop_solver:
            try:
                status = self._inner.iterate(1)
                status = json.loads(status)
            except (jpype.JException(jpype.java.lang.IllegalStateException),
                    jpype.JavaException), exception:
                clear_output()
                print(exception.stacktrace())
                return None

            status['duration'] = int((dt.utcnow() - start_time).total_seconds()) + previous_duration
            self._stats.append(status)
            self._num_iter = status['iter']

            if status['convergence'] and self._num_iter > self._min_iterations:
                break

    def _solve_iterate(self):
        """Just do one iteration."""
        try:
            status = self._inner.iterate(self._iterations)
            status = json.loads(status)
            self._stats.append(status)
        except (jpype.JException(jpype.java.lang.IllegalStateException),
                jpype.JavaException), exception:
            clear_output()
            print(exception.message())
            #print(exception.stacktrace())

    def solve(self, iterations=None, min_iterations=0, max_iterations=None, time_limit=86400, fork=False):
        """Solve the optimization problem.

        The optimizer stops automatically as soon as the dual upper bound has converged to the simulated lower bound
        (from forward sampling the Lattice). Convergence is reached as soon as the lower confidence bound of the
        simulated objective value is greater than the goal lower confidence bound defined through the current dual upper
        bound minus a gap (accuracy). The confidence level as well as the accuracy can be passed as keyword arguments
        to DynamicOptimizer.

        Arguments:
            iterations (int, optional): Number of iterations. (Default = None)

        Keyword Arguments:
            fork (bool, optional): Calculate solution in the background, rather than blocking the notebook.
                (Default=False)
            max_iterations (int, optional): Sets the maximum number of iterations of the ADDP algorithm until the algorithm
                terminates. (Default = None)
            min_iterations (int, optional): Sets the minimum number of ADDP iterations until the first convergence check.
                (Default = 0)
            time_limit (int, optional): Maximum computation time in seconds. (Default = 86400 = 1 day)

        Examples:
            >>> opt.solve() # run until convergence
            >>> opt.solve(10) # run 10 iterations
        """
        self._iterations = iterations
        self._time_limit = time_limit
        self._min_iterations = min_iterations
        self._max_iterations = max_iterations
        self.thread = threading.Thread(target=self.run)
        self.thread.start()

        if not fork:
            self.thread.join()

    def isAlive(self):
        assert hasattr(self, 'thread'), "Optimizer wasn't started yet."
        return self.thread.isAlive()

    def join(self):
        assert hasattr(self, 'thread'), "Optimizer wasn't started yet."
        self.thread.join()

    @property
    def stats(self):
        """Display algorithm information, such as dual upper bound, simulated lower bound, etc.
        """
        if len(self._stats) == 0:
            warn('No solutions in stats object. Please wait for the first iteration to finish.')
        else:
            df = pd.DataFrame(self._stats,
                              columns=['iter', 'expReward', 'simReward', 'stdError', 'sampleSize', 'numHyperplanes', 'numSolves',
                                       'duration'])
            df.index = df['iter']
            df.rename(columns={'numHyperplanes': 'hyperplanes'}, inplace=True)
            return df.drop('iter', axis=1)

    '''
    def _normalize_stdError(self, err):
        if err is None:
            return 0.0
        else:
            return err
    '''
    @property
    def policy(self):
        """Return the current Policy.
        """
        return Policy(self._inner.getPolicy())

    def plot(self, ax=None):
        """ Plot the convergence of the dual upper bound and the simulated lower bound.
        """
        assert len(self.stats) > 0, "Please solve the model before plotting it."
        if ax is None:
            fig = plt.figure()
            ax = fig.add_subplot(1, 1, 1)
            ax.figure.set_size_inches(8, 4)

        # expRewards as line
        x_exp = [stat['iter'] for stat in self._stats]
        y_exp = [stat['expReward'] for stat in self._stats]
        plt.plot(x_exp, y_exp, label='Expected objective value')

        # simRewards as line with stdError
        y_sim = [stat['simReward'] for stat in self._stats]
        y_err = [stat['stdError'] if stat['stdError'] else 0 for stat in self._stats]
        special.errorfill(x_exp, np.array(y_sim), np.array(y_err))

        plt.legend(['Dual bound', 'Sim reward (mean)', 'Sim reward (SE)'], loc='best')
        # plt.xlim((OPTIMIZER_INITIAL_ITERATIONS, len(y_passes)))
        #print (self._stats)
        plt.ylim((min(y_exp + y_sim), max(y_exp + y_sim) ))

    '''
    def _setup_solver(self):
        optimizer_builder = jpype.JClass('com.quantego.quasar.optimizer.DynamicOptimizerBuilder')

        # did we get a lattice or process?
        if 'lattice' in self.stochastic_input.__dict__ and self.stochastic_input.lattice:
            builder = optimizer_builder.createFromLattice(self._model, self.stochastic_input._inner)
        elif isinstance(self.stochastic_input, MarkovProcess):
            builder = optimizer_builder.create(self._model, self.stochastic_input._inner, int(self.kwargs.num_nodes))
        else:
            raise Exception("Didn't get a process or lattice as input.")

        if self.kwargs.num_threads > 0:
            builder.numberOfThreads(self.kwargs.num_threads)

        builder.removeRedundantHyperplanes(self.kwargs.remove_redundant_hyperplanes)
        builder.aggressiveCutRemoval(self.kwargs.aggressive_cut_removal)
        builder.probababilityUpdated(float(self.kwargs.probability_updated))
        builder.absoluteGap(float(self.kwargs.absolute_gap))
        builder.relativeGap(self.kwargs.relative_gap)
        builder.perturbation(self.kwargs.perturbation)
        builder.minSampleSize(self.kwargs.min_sample_size)
        builder.maxSampleSize(self.kwargs.max_sample_size)
        builder.confidenceInterval(self.kwargs.confidence_interval)
        builder.accuracy(float(self.kwargs.accuracy))
        builder.windowSize(self.kwargs.window_size)

        if self.kwargs.nested_cvar is not None:
            self.kwargs.min_iterations = self.kwargs.nested_cvar[2]
            self.kwargs.max_iterations = self.kwargs.nested_cvar[2]
            builder.nestedCVaR(
                float(self.kwargs.nested_cvar[0]),
                float(self.kwargs.nested_cvar[1]),
                int(self.kwargs.nested_cvar[2])
            )

        if self.kwargs.terminal_cvar is not None:
            builder.terminalCVaR(
                float(self.kwargs.terminal_cvar[0]),
                float(self.kwargs.terminal_cvar[1]),
                float(self.kwargs.terminal_cvar[2]),
                float(self.kwargs.terminal_cvar[3])
            )

        BAYESIAN = jpype.JClass("com.quantego.quasar.optimizer.FORWARDPASS").BAYESIAN
        MARKOVIAN = jpype.JClass("com.quantego.quasar.optimizer.FORWARDPASS").MARKOVIAN

        if self.kwargs.sampling_strategy.startswith('mark'):
            builder.samplingStrategy(MARKOVIAN)
        elif self.kwargs.sampling_strategy.startswith('bay'):
            builder.samplingStrategy(BAYESIAN)
        else:
            print(self.kwargs.sampling_strategy)
            raise Exception('Unknown sampling strategy.')

        CLP = jpype.JClass("com.quantego.quasar.optimizer.LINEARSOLVER").CLP
        SULUM = jpype.JClass("com.quantego.quasar.optimizer.LINEARSOLVER").SULUM

        if self.kwargs.linear_solver.startswith('clp'):
            builder.linearSolver(CLP, '')
        elif self.kwargs.linear_solver.startswith('sulum'):
            builder.linearSolver(SULUM, self.kwargs.linear_solver_license)
        else:
            raise Exception('Unknown linear solver.')

        self.solver = builder.exitOnEnter(False).build()


    def _reset(self, *args):
        self._setup_solver()
        clear_output()
    '''