try:
    from StringIO import StringIO
except ImportError:
    from io import StringIO # python2-3 compat
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import jpype

from . import config


class _QuasarDataFramePlotting(object):

    @property
    def groupby_stage(self):
        return self.groupby(level=['stage'])

    @property
    def groupby_series(self):
        return self.groupby(level=['series'])

    def spaghetti(self, ax=None, alpha=0.1, color='darkblue', xlabel='Stage', ylabel=None, title=None):
        """Make a spaghetti plot of the simulated time series.

        Keyword Arguments:
            ax (matplotlib.axes, optional): Axes object to use for plotting. Useful to gather
                multiple plots on a single figure.

        Example:
            >>> sim.rewards.spaghetti()
        """
        if ax is None:
            fig = plt.figure()
            ax = fig.add_subplot(1, 1, 1)
            ax.figure.set_size_inches(config.PLOT_SIZE)

        for group in self.groupby_series:
            ax.plot(group[1].index.get_level_values(1),group[1], alpha=alpha)
            ax.set_color_cycle(None)

        plt.setp( ax.xaxis.get_majorticklabels(), rotation=70 )
        if ylabel: ax.set_ylabel(ylabel)
        ax.set_xlabel(xlabel)
        if title is None:
            ax.set_title('Spaghetti plot of {}'.format(self.name))
        else:
            ax.set_title(title)

    def fanchart(self, ax=None, start_qt=0.05, stop_qt=.95, steps_qt=19, alpha=0.1, xlabel='Stage', ylabel=None, title=None):
        """Make a fan chart plot of the simulated time series.

        Keyword Arguments:
            ax (matplotlib.axes, optional): Axes object to use for plotting. Useful to gather
            multiple plots on a single figure.
            start_qt (float): lower quantile (Default=0.05)
            stop_qt (float): Upper quantile (Default=0.95)
            steps_qt (int): Number of steps between upper and lower quantile (Default=19)

        Example:
            >>> sim.rewards.fanchart(start_qt=0.05, stop_qt=.95, steps_qt=19)
        """
        if ax is None:
            fig = plt.figure()
            ax = fig.add_subplot(1, 1, 1)
            ax.figure.set_size_inches(config.PLOT_SIZE)

        grouped = self.groupby(level=['stage'])
        x = self.index.levels[1]
        y = grouped.mean().values.flatten()

        def plot_quantile(lower, upper, alpha_fill):
            y_lower = grouped.quantile(lower).values.flatten()
            y_upper = grouped.quantile(upper).values.flatten()
            # special.errorfill(x, y, [y_lower, y_upper], ax=ax, color='r', alpha_fill=0.1)
            ax.fill_between(x, y_lower, y_upper, alpha=alpha_fill)

        quantiles = list(np.linspace(start_qt, stop_qt, steps_qt))
        if alpha is None:
            alpha_fill = 1./len(quantiles)/2
        else:
            alpha_fill = alpha

        while len(quantiles) > 1:
            plot_quantile(quantiles.pop(0), quantiles.pop(-1), alpha_fill)

        ax.plot(x, y, linestyle='dotted')

        # Set label
        plt.setp(ax.xaxis.get_majorticklabels(), rotation=70)
        if ylabel:
            ax.set_ylabel(ylabel)
        ax.set_xlabel(xlabel)

        if title is None:
            ax.set_title('Fanchart of {}'.format(self.name))
        else:
            ax.set_title(title)



def _java_csv2list(csv_str):
    return pd.read_csv(StringIO(csv_str)).drop(['index/stage'], axis=1).as_matrix().flatten()

# # Remove once fixed upstream (https://github.com/pydata/pandas/pull/9632)
# def maybe_droplevels(index, key):
#     # drop levels
#     original_index = index
#     if isinstance(key, tuple):
#         for _ in key:
#             try:
#                 index = index.droplevel(0)
#             except:
#                 # we have dropped too much, so back out
#                 return original_index
#     else:
#         try:
#             index = index.droplevel(0)
#         except:
#             pass
#
#     return index


class QuasarSeries(pd.Series, _QuasarDataFramePlotting):
    @property
    def _constructor(self):
        return QuasarSeries

class QuasarDataFrame(pd.DataFrame, _QuasarDataFramePlotting):
    """
    Subclass of Pandas DataFrame to easily work with multi-dimensional simulation results.

    Example:
        >>> qdf.rewards
    """

    def __init__(self, *args, **kw):
        super(QuasarDataFrame, self).__init__(*args, **kw)
        self.name = self.columns[0] # plot titles

    @property
    def _constructor(self):
        return QuasarDataFrame

    _constructor_sliced = QuasarSeries

    @classmethod
    def from_csv(cls, path, **kw):

        # Are we dealing with a single series or multiple series?
        with open(path) as f:
            l1 = f.readline()
            l2 = f.readline()
            l3 = f.readline()

            # Treat as multi-index DF
            if l1.startswith(',,') and l2.startswith(',,') and l3.startswith('series,stage,'):
                return cls(pd.DataFrame.from_csv(path, header=[0,1], index_col=[0,1], **kw))
            # Treat as single-level series
            else:
                return cls(pd.DataFrame.from_csv(path, index_col=[0,1]))

    # # Remove once fixe upstream (https://github.com/pydata/pandas/pull/9632)
    # def _getitem_multilevel(self, key):
    #     loc = self.columns.get_loc(key)
    #     if isinstance(loc, (slice, pd.Series, np.ndarray, pd.Index)):
    #         new_columns = self.columns[loc]
    #         result_columns = maybe_droplevels(new_columns, key)
    #         if self._is_mixed_type:
    #             result = self.reindex(columns=new_columns)
    #             result.columns = result_columns
    #         else:
    #             new_values = self.values[:, loc]
    #             result = self._constructor(new_values, index=self.index,
    #                                columns=result_columns).__finalize__(self)
    #         if len(result.columns) == 1:
    #             top = result.columns[0]
    #             if ((type(top) == str and top == '') or
    #                     (type(top) == tuple and top[0] == '')):
    #                 result = result['']
    #                 if isinstance(result, pd.Series):
    #                     result = self._constructor_sliced(result, index=self.index, name=key)
    #
    #         result._set_is_copy(self)
    #         return result
    #     else:
    #         return self._get_item_cache(key)



    def set_time_index(self, **kwargs):
        """
        Reassign a datetime-based index to the DataFrame. Accepts the same arguments as pd.date_range, except that
        period is set to the number of stages, so that only the start date must be provided.

        You can find all available offset aliases for *freq* on `Offset Aliases <http://pandas.pydata.org/pandas-docs/stable/timeseries.html#offset-aliases>`

        Keyword Arguments:
            start (datetime.datetime): start of the time series index
            freq: string or DateOffset. Frequency strings can
                have multiples, e.g. '5H', 'D', 'h', 'm'
        """

        n_simulations, n_stages = len(self.index.levels[0]), len(self.index.levels[1])

        index_1 = range(n_simulations)
        index_2 = pd.date_range(periods=n_stages, **kwargs)
        self.index = pd.MultiIndex.from_product([index_1, index_2], names=['series', 'stage'])

    @classmethod
    def _from_time_series_sample(cls, ts_sample):
        n_simulations, n_stages = ts_sample.getSampleSize(), ts_sample.getNumStages()
        index_1 = range(n_simulations)
        index_2 = range(n_stages)
        index = pd.MultiIndex.from_product([index_1, index_2], names=['series', 'stage'])
        df = pd.DataFrame(index=index)
        for var in ts_sample.getStateVariableNames():
            csv_str = ts_sample.getStateVariablesCSV(var)
            df[var] = _java_csv2list(csv_str)
        df.__class__ = cls
        return df

    @classmethod
    def _from_simulation(cls, java_simulation):
        """Convert Java com.quantego.quasar.optimizer.Simulation to multi-index pandas.DataFrame"""

        col_index = []
        rewards = java_simulation.getRewardsCSV()
        rewards = pd.read_csv(StringIO(rewards)).drop(['index/stage'], axis=1).as_matrix()
        n_simulations, n_stages = rewards.shape
        df = rewards.flatten()
        col_index.append(('rewards', 'rewards'))

        for var in java_simulation.getAllDecisionNames():
            csv_str = java_simulation.getDecisionsCSV(var)
            df = np.vstack((df, _java_csv2list(csv_str)))
            col_index.append(('decision', var))

        for var in java_simulation.getAllDualNames():
            csv_str = java_simulation.getDualSolutionsCSV(var)
            df = np.vstack((df, _java_csv2list(csv_str)))
            col_index.append(('constraint', var))

        for var in java_simulation.getAllShadowPriceNames():
            csv_str = java_simulation.getShadowPricesCSV(var)
            df = np.vstack((df, _java_csv2list(csv_str)))
            col_index.append(('shadow_price', var))

        for var in java_simulation.getAllStateVariableNames():
            csv_str = java_simulation.getStateVariablesCSV(var)
            df = np.vstack((df, _java_csv2list(csv_str)))
            col_index.append(('state', var))

        index_1 = range(n_simulations)
        index_2 = range(n_stages)

        index = pd.MultiIndex.from_product([index_1, index_2], names=['series', 'stage'])
        col_index = pd.MultiIndex.from_tuples(col_index)
        # df = df.reshape(, )
        df = pd.DataFrame( df.reshape(len(col_index), n_simulations*n_stages).T, index=index, columns=col_index)

        df.__class__ = cls
        return df