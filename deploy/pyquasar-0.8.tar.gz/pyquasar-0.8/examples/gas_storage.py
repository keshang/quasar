from pyquasar import *

#stochastic model
initialPrice = 28.
priceSpread = 0.02
drift = 0.
volatility = 0.2
process = UnivariateGBM("price", initialPrice, drift, volatility)

#decision problem
numStages = 12
model = DecisionProblem("GasStorage").maximize()
for t in range(0,numStages):
    inject,withdraw,content = model.addVariables(t,"inject","withdraw","storage")
    #storage balance
    model += content == (lastContent if t>0 else 0) + 0.99*inject - 1.01*withdraw
    lastContent = content
    #objective function
    model += 0.99*rand("price")*withdraw - 1.01*rand("price")*inject
    #bounds
    model += inject <= 0.3
    model += withdraw <= 0.3
    model += content <= 1

opt = DynamicOptimizer(model, process, num_threads=1)
opt.solve(10)