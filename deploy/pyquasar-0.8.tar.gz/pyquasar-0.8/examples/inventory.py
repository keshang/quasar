from pyquasar import *

model = DecisionProblem("Production").maximize()
process = ARModel("Demand", 25, 5, [0.5])
# process = ARModel.create(
#     "Demand", 25., 5., [0.5]
# ).initialState([25.]).truncateZero()

initInventory = 20

for t in range(12):
    inventory, produce, sell = model.addVariables(
        t, "inventory", "produce", "sell")

    #objective function
    model += 5.0*sell - 4.5*produce - 0.5*inventory

    #inventory balance
    model += inventory == (oldInventory if t > 0 else initInventory) - sell + produce

    #bounds
    model += sell <= rand("Demand")
    model += sell <= inventory
    model += produce <= 50
    oldInventory = inventory

opt = DynamicOptimizer(model, process, num_threads=1)
opt.solve(5)
