from pyquasar import *

# Zuweisung Model
SP = DecisionProblem("LagerTestneu")
s0=0;smax=50;k=5;h=3;P=20;stages=4;

x, y = {i: None for i in range(stages)}, {i: None for i in range(stages)}


# Entscheidungsvariablen
for t in range(stages):
    x[t], y[t] = SP.addVariables(t,"x","y")

s = s0


for t in range(stages):
    SP+=x[t]*k+s*h+y[t]*P
    s = s + x[t]-rand("c")
    print(s)
    SP+=s>=0
    SP+=s<=smax+y[t]
    SP+=x[t]<=smax
    SP+=y[t]<=smax

SP+=s*h

#print(5 <= False)
print (10 >= x[0] >= 5)


# Zuweisung stochastischer Prozess
#ar = ARModel(name="c", mu=5, sigma=1, ar_coefficients=[0.5])
#Lattice(ar,stages,state_variables="c", generate_weights = 10000, number_nodes=100, sample_size=100000)
#lattice = Lattice(ar,stages,num_nodes=100,sample_size=100000)
#print(SP.minimize())
#opt=DynamicOptimizer(SP,ar)
#opt.solve()
#opt.join()