from pyquasar import *

model = DecisionProblem()
initInventory = [10, 10, 10]
prodCoeff = [0.3, 0.5, 0.2]
oldInventory = range(3)
for t in range(0, 10):
    produce = range(3)
    for i in range(0, 3):
        produce[i], inventory, sell = model.add_variables(
            t, "produce%d" % i, "inventory%d" % i, "sell%d" % i
        )
        model += 6*sell - 4*produce[i] - 0.5*inventory
        model += inventory == (
            oldInventory[i] if t > 0 else initInventory[i]) - sell + produce[i]
        model += sell <= rand("Demand%s" % i)
        model += sell <= oldInventory[i]
        oldInventory[i] = inventory
    model += sum(prodCoeff[i] * produce[i] for i in range(0, 3)) <= 10

process = MultivariateGBM(
    ["Demand0", "Demand1", "Demand2"],
    [10., 10., 10.], [0., 0., 0.],
    [0.2, 0.2, 0.2],
    [[1., 0.3, 0.7], [0.3, 1., 0.], [0.7, 0., 1.]]
)

opt = DynamicOptimizer(model,process,num_threads=1)
opt.solve()
opt.join()
print(opt.stats)
